// Service worker: cache the app shell and data so the planner opens instantly and works offline inside the halls.
const VERSION = 'imts26-v1';
const SHELL = ['/', '/index.html', '/app.js', '/data/exhibitors.js', '/data/maps.js', '/manifest.webmanifest'];
self.addEventListener('install', e => { e.waitUntil(caches.open(VERSION).then(c => c.addAll(SHELL)).then(() => self.skipWaiting())); });
self.addEventListener('activate', e => { e.waitUntil(caches.keys().then(ks => Promise.all(ks.filter(k => k !== VERSION).map(k => caches.delete(k)))).then(() => self.clients.claim())); });
self.addEventListener('fetch', e => {
  const u = new URL(e.request.url);
  if (e.request.method !== 'GET') return;
  if (u.pathname.startsWith('/api/') || u.origin !== location.origin) return; // network only (API, Supabase, fonts, CDN)
  // stale-while-revalidate for the shell + data
  e.respondWith(caches.open(VERSION).then(async c => { const cached = await c.match(e.request, { ignoreSearch: true }); const net = fetch(e.request).then(r => { if (r && r.ok) c.put(e.request, r.clone()); return r; }).catch(() => cached); return cached || net; }));
});
