(function(){
'use strict';
const R=DATA.recs, CATS=DATA.cats, H=MAPS;
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s==null?'':s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const HALL_IDS=['13','21','23','33','43'];
const HALL_NAME={}; HALL_IDS.forEach(h=>HALL_NAME[H[h].name]=h);
const BLD={'1':'east','2':'north','3':'south','4':'west'};
const DAYS=[['1','Mon 14'],['2','Tue 15'],['3','Wed 16'],['4','Thu 17'],['5','Fri 18'],['6','Sat 19']];
const SC={5:'--s5',4:'--s4',3:'--s3',2:'--s2',1:'--s1',0:'--s0'};
const cssv=n=>getComputedStyle(document.documentElement).getPropertyValue(n).trim();
const FLAGS={
 'Workholding':/workholding|work holding|fixtur|chuck|vise\b|vice\b|clamp|zero[- ]point|vacuum (table|chuck|fixture|workholding)|magnetic (chuck|workholding)/i,
 'Adhesive/UV':/adhesive|uv[- ]cur|light[- ]cur|photo[- ]?cur|glue/i,
 'Surface finishing':/polish|deburr|finish|lapping|honing|blast|tumbl|mass finishing|vibratory|superfinish/i,
 'Automation':/automation|robot|pallet|cobot|cell\b|fms\b|autonomous|agv/i,
 'Metrology/QA':/metrolog|cmm\b|inspection|measur|gauge|gaging|scanner|probe/i,
 'Aerospace':/aerospace|aircraft|defen[cs]e|turbine|blisk/i,
 'Thermal/warpage':/warp|stress reliev|straighten|thermal|distortion|heat treat/i,
 'Software/CAM':/cam\b|cad\b|software|mes\b|erp\b|digital twin|simulation/i,
};
const byId={};
R.forEach(r=>{ byId[r.i]=r; r.catNames=r.g.map(id=>CATS[id]||''); r.hay=(r.n+' '+r.d+' '+r.catNames.join(' ')+' '+r.k+' '+r.c+' '+r.b.map(b=>b[0]).join(' ')).toLowerCase();
  r.flags=Object.keys(FLAGS).filter(k=>FLAGS[k].test(r.hay)); r.halls=[...new Set(r.b.map(b=>b[1]))]; r.secs=[...new Set(r.b.map(b=>b[2]).filter(Boolean))];
  r.groups=[...new Set(r.catNames.map(c=>c.split('>')[0].trim()))]; r.hallIds=r.halls.map(n=>HALL_NAME[n]).filter(Boolean); });
// booth geometry index
const BOOTH={}; // booth -> {h, ring, cx, cy}
HALL_IDS.forEach(h=>H[h].booths.forEach(b=>{ const ring=b[2]; let cx=0,cy=0; ring.forEach(p=>{cx+=p[0];cy+=p[1];}); cx/=ring.length; cy/=ring.length; BOOTH[b[0]]={h,ring,cx,cy,ids:b[1],name:b[3]}; }));

// ================= STATE & SYNC (Supabase) =================
let marks={}; // id -> {s,d,a,n,v,vb,vt,met,fu,nx,t}
let meta={team:[], mins:{5:20,4:15,3:10,2:7,1:5,w:3}, mt:0};
const LS='imts26-hosted';
try{ const s=JSON.parse(localStorage.getItem(LS)||'{}'); marks=s.marks||{}; if(s.meta) meta=Object.assign(meta,s.meta); }catch(e){}
let me=''; try{ me=localStorage.getItem('imts26-me')||''; }catch(e){}
let sb=null, session=null, allowed=null, CFG=null, online=navigator.onLine;
const setSync=(st,tx)=>{ $('#syncDot').className='dot '+st; $('#syncTxt').textContent=tx; };
setSync('local','connecting…');
let marksVer=0;
function saveLocal(){ try{localStorage.setItem(LS,JSON.stringify({marks,meta}));}catch(e){} }
function mergeIn(rm, rmeta){ let ch=false; for(const id in rm){ const a=marks[id], b=rm[id]; if(!a||(b.t||0)>(a.t||0)){ marks[id]=b; ch=true; } }
  if(rmeta&&(rmeta.mt||0)>(meta.mt||0)){ meta=Object.assign({},meta,rmeta); ch=true; } if(ch){ marksVer++; saveLocal(); } return ch; }
// pending queue: ids (and 'meta') waiting to be written; flushed when online
let pending=new Set(); try{ (JSON.parse(localStorage.getItem(LS+'-pending')||'[]')).forEach(x=>pending.add(x)); }catch(e){}
function savePending(){ try{localStorage.setItem(LS+'-pending',JSON.stringify([...pending]));}catch(e){} }
let flushTimer=null; function persist(id){ saveLocal(); if(id) pending.add(id); savePending(); clearTimeout(flushTimer); flushTimer=setTimeout(flush,600); }
async function flush(){ if(!sb||!session||!pending.size) return; if(!navigator.onLine){ setSync('local','offline — '+pending.size+' change'+(pending.size>1?'s':'')+' queued'); return; }
  const ids=[...pending]; const rows=ids.filter(x=>x!=='meta'&&marks[x]).map(x=>Object.assign({exh_id:x, updated_by:me||session.user.email},marks[x]));
  const dels=ids.filter(x=>x!=='meta'&&!marks[x]);
  try{ if(rows.length){ const {error}=await sb.from('marks').upsert(rows,{onConflict:'exh_id'}); if(error) throw error; }
    if(dels.length){ const {error}=await sb.from('marks').delete().in('exh_id',dels); if(error) throw error; }
    if(pending.has('meta')){ const {error}=await sb.from('settings').upsert({id:'team',data:{team:meta.team,mins:meta.mins},mt:meta.mt}); if(error) throw error; }
    ids.forEach(x=>pending.delete(x)); savePending(); setSync('on','synced'); }
  catch(e){ console.warn('sync',e); setSync('local','sync failed — retrying'); setTimeout(flush,8000); } }
window.addEventListener('online',()=>{ online=true; flush(); }); window.addEventListener('offline',()=>{ online=false; setSync('local','offline — changes are kept on this device'); });
const M=id=>marks[id]||{s:0,n:'',v:false,vb:'',vt:0,d:'',a:'',met:'',fu:'',nx:'',t:0};
function setM(id,patch){ const m=Object.assign({s:0,n:'',v:false,vb:'',vt:0,d:'',a:'',met:'',fu:'',nx:''},marks[id]||{},patch,{t:Date.now()});
  if(!m.s&&!m.n&&!m.v&&!m.d&&!m.a&&!m.met&&!m.fu&&!m.nx) delete marks[id]; else marks[id]=m; marksVer++; persist(id); }
function setMeta(){ meta.mt=Date.now(); persist('meta'); }
const starOf=id=>M(id).s;
const mins=()=>meta.mins||{5:20,4:15,3:10,2:7,1:5,w:3};
const estMin=s=>(mins()[s]||0)+(mins().w||0);
let tt; function toast(msg,ms){ const t=$('#toast'); t.textContent=msg; t.classList.add('show'); clearTimeout(tt); tt=setTimeout(()=>t.classList.remove('show'),ms||2200); }

// ---- auth gate ----
const gate=$('#gate'), gateMsg=$('#gateMsg'), gateBtns=$('#gateBtns');
function showGate(msg, btns){ gate.hidden=false; gateMsg.innerHTML=msg; gateBtns.innerHTML=btns||''; }
async function boot(){
  try{ CFG=await (await fetch('/api/config',{cache:'no-store'})).json(); }catch(e){ CFG={ok:false,error:'Cannot reach /api/config'}; }
  if(!CFG.ok){ showGate('The server is not configured yet.<br><span class="help">'+esc(CFG.error||'')+'</span>'); return; }
  sb=supabase.createClient(CFG.supabaseUrl, CFG.supabaseAnonKey, {auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}});
  const {data:{session:s0}}=await sb.auth.getSession(); await onSession(s0);
  sb.auth.onAuthStateChange((ev,s)=>{ if(ev==='SIGNED_OUT'){ session=null; allowed=null; showGate('Signed out.', signInBtn()); } else if(s&&(!session||s.user.id!==session.user.id)) onSession(s); else session=s; });
}
const signInBtn=()=>`<button class="gbtn" id="gSignIn"><svg width="18" height="18" viewBox="0 0 48 48"><path fill="#EA4335" d="M24 9.5c3.5 0 6.6 1.2 9 3.5l6.7-6.7C35.6 2.6 30.2 0 24 0 14.6 0 6.5 5.4 2.5 13.3l7.8 6C12.2 13.6 17.6 9.5 24 9.5z"/><path fill="#4285F4" d="M46.5 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.7c-.6 3-2.3 5.5-4.8 7.2l7.5 5.8c4.4-4 7.1-10 7.1-17.5z"/><path fill="#FBBC05" d="M10.3 28.7A14.5 14.5 0 0 1 9.5 24c0-1.6.3-3.2.8-4.7l-7.8-6A24 24 0 0 0 0 24c0 3.9.9 7.5 2.5 10.7l7.8-6z"/><path fill="#34A853" d="M24 48c6.5 0 11.9-2.1 15.9-5.8l-7.5-5.8c-2.1 1.4-4.9 2.3-8.4 2.3-6.4 0-11.8-4.1-13.7-9.8l-7.8 6C6.5 42.6 14.6 48 24 48z"/></svg> Sign in with Google</button>`;
gateBtns.addEventListener('click',async e=>{ if(e.target.closest('#gSignIn')){ gateMsg.textContent='Redirecting to Google…'; const {error}=await sb.auth.signInWithOAuth({provider:'google',options:{redirectTo:location.origin+location.pathname}}); if(error) showGate('Sign-in failed: '+esc(error.message), signInBtn()); }
  if(e.target.closest('#gOut')){ await sb.auth.signOut(); } });
$('#signOut').addEventListener('click',async()=>{ if(confirm('Sign out of the planner on this device?')) await sb.auth.signOut(); });
async function onSession(s){ session=s; if(!s){ showGate('Sign in with the Google account that was invited.', signInBtn()); return; }
  showGate('Checking access for '+esc(s.user.email)+'…');
  const {data:al,error}=await sb.from('allowed_emails').select('email,role,name').ilike('email',s.user.email).maybeSingle();
  if(error){ showGate('Could not check access: '+esc(error.message), signInBtn()); return; }
  if(!al){ showGate('<b>'+esc(s.user.email)+'</b> has not been invited yet.<br><span class="help">Ask Akhil to add this address under Plan → Team access, then reload.</span>', `<button class="gbtn" id="gOut">Use a different account</button>`); return; }
  allowed=al; if(!me){ me=al.name||s.user.user_metadata?.full_name||s.user.email.split('@')[0]; try{localStorage.setItem('imts26-me',me);}catch(e){} } $('#meName').value=me;
  gate.hidden=true; await initialLoad(); subscribeRealtime(); flush(); renderAll(); }
async function initialLoad(){ setSync('local','loading…');
  const {data:rows,error}=await sb.from('marks').select('*'); if(error){ setSync('local','load failed: '+error.message); return; }
  const rm={}; rows.forEach(r=>{ rm[r.exh_id]={s:r.s,d:r.d,a:r.a,n:r.n,v:r.v,vb:r.vb,vt:Number(r.vt)||0,met:r.met,fu:r.fu,nx:r.nx,t:Number(r.t)||0}; });
  // local rows newer than server (edited offline) stay pending; server-only rows come in
  for(const id in rm){ const a=marks[id]; if(!a||(rm[id].t||0)>=(a.t||0)) marks[id]=rm[id]; }
  for(const id in marks){ if(!rm[id]&&!pending.has(id)) pending.add(id); } // local marks unknown to server → push
  const {data:st}=await sb.from('settings').select('*').eq('id','team').maybeSingle(); if(st&&st.data&&(st.mt||0)>=(meta.mt||0)){ meta=Object.assign({},meta,st.data,{mt:st.mt}); } else if(meta.team.length||meta.mt) pending.add('meta');
  if(me&&!meta.team.includes(me)){ meta.team.push(me); setMeta(); }
  marksVer++; saveLocal(); savePending(); setSync('on','synced'); loadRecordings(); }
function subscribeRealtime(){ sb.channel('plan').on('postgres_changes',{event:'*',schema:'public',table:'marks'},p=>{ if(p.eventType==='DELETE'){ const id=p.old.exh_id; if(marks[id]&&!pending.has(id)){ delete marks[id]; marksVer++; saveLocal(); renderAll(); } return; } const r=p.new; const rm={[r.exh_id]:{s:r.s,d:r.d,a:r.a,n:r.n,v:r.v,vb:r.vb,vt:Number(r.vt)||0,met:r.met,fu:r.fu,nx:r.nx,t:Number(r.t)||0}}; if(mergeIn(rm)) renderAll(); })
  .on('postgres_changes',{event:'*',schema:'public',table:'settings'},p=>{ const r=p.new; if(r&&r.id==='team'&&(r.mt||0)>(meta.mt||0)){ meta=Object.assign({},meta,r.data,{mt:r.mt}); saveLocal(); renderAll(); } })
  .on('postgres_changes',{event:'*',schema:'public',table:'recordings'},()=>loadRecordings())
  .subscribe(st=>{ if(st==='SUBSCRIBED') setSync('on','synced · live'); }); }
$('#meName').addEventListener('change',e=>{ me=e.target.value.trim(); try{localStorage.setItem('imts26-me',me);}catch(x){} if(me&&!meta.team.includes(me)){ meta.team.push(me); setMeta(); } renderAll(); });
async function api(path, body){ const {data:{session:s}}=await sb.auth.getSession(); const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','Authorization':'Bearer '+(s?s.access_token:'')},body:JSON.stringify(body||{})}); let j={}; try{ j=await r.json(); }catch(e){} if(!r.ok) throw new Error(j.error||('HTTP '+r.status)); return j; }

// ================= NAV =================
let cur='explore';
function showTab(t){ cur=t; $$('.tabs button').forEach(b=>b.setAttribute('aria-selected',b.dataset.tab===t)); ['explore','map','walk','plan','halls','meet'].forEach(v=>$('#v-'+v).hidden=v!==t);
  if(t==='map'){ requestAnimationFrame(()=>{ resizeMap(); if(!mapInit){ mapInit=true; fitHall(); } draw(); }); } if(t==='walk') renderWalk(); if(t==='plan') renderPlan(); if(t==='halls') renderHalls(); if(t==='meet') renderMeet(); }
$('.tabs').addEventListener('click',e=>{ const b=e.target.closest('button'); if(b) showTab(b.dataset.tab); });
function renderAll(){ renderList(); if(cur==='map') draw(); if(cur==='walk') renderWalk(); if(cur==='plan') renderPlan(); if(cur==='halls') renderHalls(); }

// ================= EXPLORE =================
const F={q:'',star:new Set(),flag:new Set(),hall:new Set(),sec:'',country:'',group:'',cat:'',sort:'name'};
function chipGroup(el,vals,set){ el.innerHTML=''; vals.forEach(v=>{ const b=document.createElement('button'); b.className='chip'; b.dataset.v=v.value||v; b.textContent=v.label||v; el.appendChild(b); });
  el.addEventListener('click',e=>{ const b=e.target.closest('.chip'); if(!b) return; const v=b.dataset.v; set.has(v)?set.delete(v):set.add(v); b.classList.toggle('on'); page=1; renderList(); }); }
chipGroup($('#fFlag'),Object.keys(FLAGS),F.flag);
chipGroup($('#fHall'),HALL_IDS.map(h=>({value:H[h].name,label:H[h].short})),F.hall);
$('#fStar').addEventListener('click',e=>{ const b=e.target.closest('.chip'); if(!b) return; const v=b.dataset.v; F.star.has(v)?F.star.delete(v):F.star.add(v); b.classList.toggle('on'); page=1; renderList(); });
function fillSel(el,vals){ vals.forEach(v=>{ const o=document.createElement('option'); o.value=v.value!==undefined?v.value:v; o.textContent=v.label||v; el.appendChild(o); }); }
fillSel($('#fSec'),[...new Set(R.flatMap(r=>r.secs))].sort());
fillSel($('#fCountry'),[...new Set(R.map(r=>r.k).filter(Boolean))].sort());
fillSel($('#fCatGroup'),[...new Set(Object.values(CATS).map(c=>c.split('>')[0].trim()))].sort());
function fillCats(){ const el=$('#fCat'); el.innerHTML='<option value="">All categories</option>'; Object.entries(CATS).filter(([id,n])=>!F.group||n.split('>')[0].trim()===F.group).sort((a,b)=>a[1].localeCompare(b[1])).forEach(([id,n])=>{ const o=document.createElement('option'); o.value=id; o.textContent=n.replace(/^[^>]*>\s*/,''); el.appendChild(o); }); }
fillCats();
['fSec','fCountry','fCatGroup','fCat','sort'].forEach(id=>$('#'+id).addEventListener('change',e=>{ const v=e.target.value; if(id==='fSec')F.sec=v; if(id==='fCountry')F.country=v; if(id==='fCatGroup'){F.group=v;F.cat='';fillCats();} if(id==='fCat')F.cat=v; if(id==='sort')F.sort=v; page=1; renderList(); }));
let qt; $('#q').addEventListener('input',e=>{ clearTimeout(qt); qt=setTimeout(()=>{ F.q=e.target.value.trim().toLowerCase(); page=1; renderList(); },180); });
$('#clearF').addEventListener('click',()=>{ F.q='';F.star.clear();F.flag.clear();F.hall.clear();F.sec='';F.country='';F.group='';F.cat='';$('#q').value='';['fSec','fCountry','fCatGroup','fCat'].forEach(id=>$('#'+id).value='');fillCats();$$('.chip.on').forEach(c=>c.classList.remove('on')); page=1; renderList(); });
$('#ftoggle').addEventListener('click',()=>$('#aside').classList.toggle('collapsed'));
if(window.innerWidth<760) $('#aside').classList.add('collapsed');
function filtered(){ const terms=F.q?F.q.split(/\s+/).filter(Boolean):[];
  return R.filter(r=>{ const m=M(r.i);
    if(F.star.size){ let ok=false; for(const v of F.star){ if(v==='visited'&&m.v) ok=true; else if(v==='skip'&&m.s===-1) ok=true; else if(v==='none'&&!m.s) ok=true; else if(String(m.s)===v) ok=true; } if(!ok) return false; }
    if(F.flag.size&&![...F.flag].some(f=>r.flags.includes(f))) return false;
    if(F.hall.size&&!r.halls.some(h=>F.hall.has(h))) return false;
    if(F.sec&&!r.secs.includes(F.sec)) return false;
    if(F.country&&r.k!==F.country) return false;
    if(F.group&&!r.groups.includes(F.group)) return false;
    if(F.cat&&!r.g.includes(+F.cat)) return false;
    if(terms.length&&!terms.every(t=>r.hay.includes(t))) return false;
    return true; }); }
function sortRecs(a){ const s=F.sort; if(s==='name') a.sort((x,y)=>x.n.localeCompare(y.n)); if(s==='booth') a.sort((x,y)=>(x.b[0]?x.b[0][0]:'z').localeCompare(y.b[0]?y.b[0][0]:'z')); if(s==='star') a.sort((x,y)=>(M(y.i).s)-(M(x.i).s)||x.n.localeCompare(y.n)); if(s==='cats') a.sort((x,y)=>y.g.length-x.g.length||x.n.localeCompare(y.n)); return a; }
let page=1; const PAGE=60; let curList=[];
function starsHTML(id,size){ const s=M(id).s; return `<span class="stars" data-id="${id}" style="--sc:var(${SC[Math.max(s,0)]})">${[1,2,3,4,5].map(n=>`<button data-s="${n}" class="${s>=n?'on':''}" title="${n} star${n>1?'s':''}">${s>=n?'★':'☆'}</button>`).join('')}<button class="skip ${s===-1?'on':''}" data-s="-1" title="Skip">skip</button></span>`; }
function rowHTML(r){ const m=M(r.i); const b0=r.b[0]||['—','','']; const cls=m.s===-1?'s0':(m.s?'s'+m.s:'');
  return `<article class="row ${cls}" data-id="${r.i}">
    <div class="booth">${esc(b0[0])}${r.b.length>1?`<span style="font-size:13px;color:var(--ink2)"> +${r.b.length-1}</span>`:''}<small>${esc(b0[1].replace(' Building, Level',' · L'))}</small></div>
    <div><div class="name">${esc(r.n)}${m.v?'<span class="v">✓ visited'+(m.vb?' · '+esc(m.vb):'')+'</span>':''}${r.f?'<span style="color:var(--accent);font-size:11px;font-weight:600;text-transform:uppercase">Featured</span>':''}</div>
      <div class="meta">${r.secs.length?`<span class="sec">${esc(r.secs.join(' / '))}</span>`:''}<span>${esc(r.k)}${r.c?' · '+esc(r.c):''}</span>${r.flags.map(f=>`<span class="flag">${esc(f)}</span>`).join('')}<span>${r.g.length} cats</span></div>
      ${r.d?`<div class="desc">${esc(r.d)}</div>`:''}</div>
    <div class="ctl">${starsHTML(r.i)}<span class="dn">${m.d?'Day: '+DAYS.find(d=>d[0]===m.d)[1]:''}${m.a?' · '+esc(m.a):''}${m.n?' · ✎ '+esc(m.n.slice(0,60)):''}</span></div>
  </article>`; }
function renderList(){ curList=sortRecs(filtered()); $('#cntN').textContent=curList.length; const slice=curList.slice(0,page*PAGE); $('#list').innerHTML=slice.map(rowHTML).join(''); $('#moreBtn').style.display=curList.length>slice.length?'':'none'; $('#moreBtn').textContent=`Show more (${curList.length-slice.length} remaining)`; }
$('#moreBtn').addEventListener('click',()=>{ page++; renderList(); });
document.addEventListener('click',e=>{ const sb=e.target.closest('.stars button'); if(sb){ e.stopPropagation(); const id=sb.closest('.stars').dataset.id; const s=+sb.dataset.s; setM(id,{s:M(id).s===s?0:s}); renderAll(); if($('#sheet').classList.contains('open')&&sheetId===id) openSheet(id); return; } });
$('#list').addEventListener('click',e=>{ const row=e.target.closest('.row'); if(row&&!e.target.closest('.stars')) openSheet(row.dataset.id); });
$('#exportCsv').addEventListener('click',async()=>{ const lines=[['Stars','Visited','Visited by','Visited at','Day','Person','Exhibitor','Booth','Hall','Sector','Country','Website','Phone','Note','Met','Follow-up','Next step'].join(',')];
  const q=s=>'"'+String(s||'').replace(/"/g,'""')+'"'; R.forEach(r=>{ const m=M(r.i); if(!m.s&&!m.n&&!m.v) return; lines.push([m.s===-1?'skip':m.s,m.v?'yes':'',m.vb,m.vt?new Date(m.vt).toISOString():'',m.d?DAYS.find(d=>d[0]===m.d)[1]:'',m.a,r.n,r.b.map(b=>b[0]).join(' '),r.halls.join('; '),r.secs.join('; '),r.k,r.w,r.p,m.n,m.met,m.fu,m.nx].map(q).join(',')); });
  try{ await navigator.clipboard.writeText(lines.join('\n')); toast(`Copied ${lines.length-1} rows as CSV — paste into Excel`); }catch(e){ console.log(lines.join('\n')); toast('Clipboard blocked — CSV printed to console'); } });

// ================= DETAIL SHEET =================
let sheetId=null;
function openSheet(id){ const r=byId[id]; if(!r) return; sheetId=id; const m=M(id);
  const site=r.w?`<a href="${esc(r.w)}" target="_blank" rel="noopener">${esc(r.w.replace(/^https?:\/\/(www\.)?/,'').replace(/\/$/,''))}</a>`:'';
  const dayOpts=`<option value="">— no day —</option>`+DAYS.map(d=>`<option value="${d[0]}" ${m.d===d[0]?'selected':''}>${d[1]}</option>`).join('');
  const whoOpts=`<option value="">— nobody —</option>`+meta.team.map(t=>`<option ${m.a===t?'selected':''}>${esc(t)}</option>`).join('');
  $('#sheetPanel').innerHTML=`<button class="close" id="sheetClose" aria-label="Close">×</button>
    <h2>${esc(r.n)}</h2>
    <div class="bl">${r.b.map(b=>`<button class="btn sm" data-goto="${esc(b[0])}"><span class="bn">${esc(b[0])}</span> ${esc(b[1].replace(' Building, Level',' L'))}${b[2]?' · '+esc(b[2]):''} → map</button>`).join('')}</div>
    <div class="help">${esc(r.k)}${r.c?' · '+esc(r.c):''}${r.s?' '+esc(r.s):''} ${site?' · '+site:''}${r.p?' · '+esc(r.p):''} · <a href="https://directory.imts.com/8_0/exhibitor/${r.i}/" target="_blank" rel="noopener">IMTS listing ↗</a></div>
    <div class="sec"><h3>Priority</h3><div style="display:flex;align-items:center;gap:12px;flex-wrap:wrap">${starsHTML(id)}<span class="help">★5 must · ★3 can see · ★1 if time</span></div></div>
    <div class="grid"><div><span class="lbl">Day</span><select class="sel" id="shDay">${dayOpts}</select></div><div><span class="lbl">Person</span><select class="sel" id="shWho">${whoOpts}</select></div></div>
    <div class="sec"><h3>Visit</h3><div class="actions"><button class="vbtn ${m.v?'on':''}" id="shVisit">${m.v?'✓ Visited'+(m.vb?' by '+esc(m.vb):''):'Mark visited'}</button><button class="btn" id="shHere">I'm at this booth</button><button class="btn primary" id="shRec">● Record conversation</button></div>
      <div id="shMeet">${meetListHTML(recordingsFor(id))}</div>
      <span class="lbl" style="margin-top:8px">Note (what to ask / look for)</span><textarea id="shNote" placeholder="e.g. ask about vacuum chuck pricing for 6061 plates">${esc(m.n)}</textarea></div>
    <div class="sec"><h3>Contact & follow-up</h3>
      <span class="lbl">Met (name, role)</span><input type="text" id="shMet" value="${esc(m.met)}" placeholder="e.g. John Smith, Regional Sales">
      <span class="lbl" style="margin-top:6px">Follow-up promised</span><input type="text" id="shFu" value="${esc(m.fu)}" placeholder="e.g. send catalogue + India pricing">
      <span class="lbl" style="margin-top:6px">Next step (ours)</span><input type="text" id="shNx" value="${esc(m.nx)}" placeholder="e.g. email intro to Yuvaraj, request demo"></div>
    <div class="sec"><h3>About</h3><div class="help" style="color:var(--ink2)">${esc(r.d)||'No description on the IMTS listing.'}</div>
      <div class="cats">${r.catNames.map(c=>`<span>${esc(c)}</span>`).join('')||'<span>No product categories listed</span>'}</div>
      ${r.flags.length?`<div class="help">Flags: ${r.flags.map(esc).join(', ')}</div>`:''}</div>`;
  $('#sheet').classList.add('open');
  $('#sheetClose').onclick=closeSheet;
  $('#shDay').onchange=e=>{ setM(id,{d:e.target.value}); renderAll(); };
  $('#shWho').onchange=e=>{ setM(id,{a:e.target.value}); renderAll(); };
  $('#shVisit').onclick=()=>{ const mm=M(id); setM(id,{v:!mm.v,vb:!mm.v?me:'',vt:!mm.v?Date.now():0}); openSheet(id); renderAll(); };
  $('#shRec').onclick=()=>startRecorder(r);
  $('#shMeet').addEventListener('click',e=>{ const d=e.target.closest('[data-rec]'); if(d){ openMeeting(d.dataset.rec); } });
  $('#shHere').onclick=()=>{ const b=r.b[0]; if(b&&BOOTH[b[0]]){ setPosBooth(b[0]); closeSheet(); showTab('map'); toast('Position set at booth '+b[0]); } };
  const deb=(el,key)=>{ el.addEventListener('input',()=>{ clearTimeout(el._t); el._t=setTimeout(()=>{ setM(id,{[key]:el.value.trim()}); renderList(); },500); }); };
  deb($('#shNote'),'n'); deb($('#shMet'),'met'); deb($('#shFu'),'fu'); deb($('#shNx'),'nx');
  $$('#sheetPanel [data-goto]').forEach(b=>b.onclick=()=>{ closeSheet(); gotoBooth(b.dataset.goto); }); }
function closeSheet(){ $('#sheet').classList.remove('open'); sheetId=null; }
$('#sheetBg').addEventListener('click',closeSheet);

// ================= MAP ENGINE =================
const cv=$('#map'), ctx=cv.getContext('2d'); let mapInit=false;
let hall='43'; let view={cx:0,cy:0,scale:0.05}; // scale = px per CAD unit
let pos=null; // {h, x, y, acc, src:'gps'|'manual', lon, lat}
let route=null; // {h, stops:[{booth,id,name,cell,dist}], path:[[x,y]...]}
let gpsWatch=null; let mapLayers={pois:true,labels:true};
const gridCache={}; const bgCache={};
function gridOf(h){ if(gridCache[h]) return gridCache[h]; const g=H[h].grid; const n=g.rows*g.cols; const a=new Uint8Array(n); let i=0,v=0; for(const run of g.rle){ if(v){ a.fill(1,i,i+run); } i+=run; v^=1; } gridCache[h]=a; return a; }
function cellOf(h,x,y){ const g=H[h].grid; const c=Math.floor((x-g.ox)/g.cs), r=Math.floor((y-g.oy)/g.cs); if(c<0||r<0||c>=g.cols||r>=g.rows) return -1; return r*g.cols+c; }
function cellXY(h,idx){ const g=H[h].grid; const r=Math.floor(idx/g.cols), c=idx%g.cols; return [g.ox+(c+.5)*g.cs, g.oy+(r+.5)*g.cs]; }
function nearestWalkable(h,x,y,maxR=12){ const g=H[h].grid, a=gridOf(h); const c0=Math.floor((x-g.ox)/g.cs), r0=Math.floor((y-g.oy)/g.cs); let best=-1,bd=1e9;
  for(let dr=-maxR;dr<=maxR;dr++) for(let dc=-maxR;dc<=maxR;dc++){ const r=r0+dr,c=c0+dc; if(r<0||c<0||r>=g.rows||c>=g.cols) continue; const i=r*g.cols+c; if(a[i]) continue; const d=dr*dr+dc*dc; if(d<bd){bd=d;best=i;} } return best; }
function boothCells(h,booth){ // walkable cells adjacent to the booth footprint
  const b=BOOTH[booth]; const g=H[h].grid, a=gridOf(h); const xs=b.ring.map(p=>p[0]), ys=b.ring.map(p=>p[1]);
  const c0=Math.floor((Math.min(...xs)-g.ox)/g.cs)-1, c1=Math.floor((Math.max(...xs)-g.ox)/g.cs)+1, r0=Math.floor((Math.min(...ys)-g.oy)/g.cs)-1, r1=Math.floor((Math.max(...ys)-g.oy)/g.cs)+1; const out=[];
  for(let r=r0;r<=r1;r++) for(let c=c0;c<=c1;c++){ if(r<0||c<0||r>=g.rows||c>=g.cols) continue; if(r!==r0&&r!==r1&&c!==c0&&c!==c1) continue; const i=r*g.cols+c; if(!a[i]) out.push(i); }
  if(!out.length){ const i=nearestWalkable(h,b.cx,b.cy,20); if(i>=0) out.push(i); } return out; }
function bfs(h,src){ const g=H[h].grid, a=gridOf(h), n=a.length; const dist=new Int32Array(n).fill(-1), par=new Int32Array(n).fill(-1); const q=new Int32Array(n); let qh=0,qt=0; dist[src]=0; q[qt++]=src; const W=g.cols;
  while(qh<qt){ const i=q[qh++]; const r=(i/W)|0, c=i-r*W; const nb=[]; if(c>0) nb.push(i-1); if(c<W-1) nb.push(i+1); if(r>0) nb.push(i-W); if(r<g.rows-1) nb.push(i+W);
    for(const j of nb){ if(a[j]||dist[j]>=0) continue; dist[j]=dist[i]+1; par[j]=i; q[qt++]=j; } } return {dist,par}; }
function pathTo(par,to){ const p=[]; let i=to; while(i>=0){ p.push(i); i=par[i]; } return p.reverse(); }
// coordinate transforms
const toV=(h,x,y)=>[x*H[h].k,y*H[h].k];
function cadToLonLat(h,x,y){ const A=H[h].A; const [vx,vy]=toV(h,x,y); return [A[0]*vx+A[1]*vy+A[2], A[3]*vx+A[4]*vy+A[5]]; }
function lonLatToCad(h,lon,lat){ const Rv=H[h].R; const vx=Rv[0]*lon+Rv[1]*lat+Rv[2], vy=Rv[3]*lon+Rv[4]*lat+Rv[5]; return [vx/H[h].k, vy/H[h].k]; }
function pip(x,y,poly){ let ins=false; for(let i=0,j=poly.length-1;i<poly.length;j=i++){ const xi=poly[i][0],yi=poly[i][1],xj=poly[j][0],yj=poly[j][1]; if((yi>y)!==(yj>y)&&x<(xj-xi)*(y-yi)/(yj-yi)+xi) ins=!ins; } return ins; }
function hallAt(lon,lat){ for(const h of HALL_IDS){ if(pip(lon,lat,H[h].geofence)) return h; } return null; }
function nearestHall(lon,lat){ let best=null,bd=1e9; for(const h of HALL_IDS){ const gf=H[h].geofence; let cx=0,cy=0; gf.forEach(p=>{cx+=p[0];cy+=p[1];}); cx/=gf.length; cy/=gf.length; const d=Math.hypot((lon-cx)*82000,(lat-cy)*111000); if(d<bd){bd=d;best=h;} } return [best,bd]; }
// screen transforms
const sx=x=>(x-view.cx)*view.scale+cv.width/2/dpr(), sy=y=>-(y-view.cy)*view.scale+cv.height/2/dpr();
const dpr=()=>window.devicePixelRatio||1;
function resizeMap(){ const w=$('#mapwrap'); const rect=w.getBoundingClientRect(); cv.width=Math.max(1,Math.round(rect.width*dpr())); cv.height=Math.max(1,Math.round(rect.height*dpr())); }
function fitHall(){ const e=H[hall].ext; const w=cv.width/dpr(), hh=cv.height/dpr(); view.cx=(e[0]+e[2])/2; view.cy=(e[1]+e[3])/2; view.scale=Math.min(w/(e[2]-e[0]), hh/(e[3]-e[1]))*0.95; }
function bgImage(h){ if(bgCache[h]) return bgCache[h]; const g=H[h].grid, a=gridOf(h); const c=document.createElement('canvas'); c.width=g.cols; c.height=g.rows; const x=c.getContext('2d'); const img=x.createImageData(g.cols,g.rows); const walk=hex(cssv('--map-walk')), blk=hex(cssv('--map-bg'));
  for(let r=0;r<g.rows;r++) for(let cc=0;cc<g.cols;cc++){ const i=r*g.cols+cc; const o=((g.rows-1-r)*g.cols+cc)*4; const col=a[i]?blk:walk; img.data[o]=col[0];img.data[o+1]=col[1];img.data[o+2]=col[2];img.data[o+3]=255; }
  x.putImageData(img,0,0); bgCache[h]=c; return c; }
function hex(s){ const m=s.replace('#',''); return [parseInt(m.slice(0,2),16),parseInt(m.slice(2,4),16),parseInt(m.slice(4,6),16)]; }
let themeKey=''; function checkTheme(){ const k=cssv('--map-walk'); if(k!==themeKey){ themeKey=k; for(const h in bgCache) delete bgCache[h]; } }
function boothStar(b){ let best=0,bestId=null; for(const id of b.ids){ const s=M(id).s; if(s>best){best=s;bestId=id;} } return [best,bestId]; }
let rafPending=false; function draw(){ if(rafPending) return; rafPending=true; requestAnimationFrame(()=>{ rafPending=false; drawNow(); }); }
// Static layer: background grid + booths + labels + POIs rendered once per (hall, scale, marks) into an offscreen canvas; panning only blits it.
let stat={key:'',canvas:null,scale:0,ox:0,oy:0,hall:''}; let zoomTimer=null; let zooming=false;
function zoomTick(){ zooming=true; clearTimeout(zoomTimer); zoomTimer=setTimeout(()=>{ zooming=false; zoomTimer=null; draw(); },160); }
function staticKey(){ return [hall,Math.round(view.scale*1e4),marksVer,themeKey,$('#mapMin').value,$('#mapDay').value].join('|'); }
function buildStatic(){ const hd=H[hall], e=hd.ext; const s=view.scale; const d=dpr(); let w=(e[2]-e[0])*s, h=(e[3]-e[1])*s; const cap=3000/d; const f=Math.min(1,cap/Math.max(w,h)); const ss=s*f; w=Math.ceil((e[2]-e[0])*ss); h=Math.ceil((e[3]-e[1])*ss);
  const c=stat.canvas||document.createElement('canvas'); c.width=Math.max(1,Math.round(w*d)); c.height=Math.max(1,Math.round(h*d)); const x=c.getContext('2d'); x.setTransform(d,0,0,d,0,0);
  const SX=v=>(v-e[0])*ss, SY=v=>(e[3]-v)*ss; renderStatic(x,SX,SY,ss); stat={key:staticKey(),canvas:c,scale:ss,ox:e[0],oy:e[3],w,h,hall}; }
function renderStatic(x,SX,SY,s){ const hd=H[hall], g=hd.grid, min=+$('#mapMin').value, day=$('#mapDay').value;
  x.fillStyle=cssv('--map-bg'); x.fillRect(0,0,1e5,1e5);
  const img=bgImage(hall); x.imageSmoothingEnabled=false; x.drawImage(img,SX(g.ox),SY(g.oy+g.rows*g.cs),g.cols*g.cs*s,g.rows*g.cs*s); x.imageSmoothingEnabled=true;
  const showNum=s>0.12, showName=s>0.2; const lineC=cssv('--map-line'), boothC=cssv('--map-booth'), textC=cssv('--map-text'); const skipC=cssv('--panel3');
  x.lineWidth=Math.max(0.5,Math.min(1.5,s*8)); const numFont=`${Math.max(9,Math.min(14,s*90))}px "Barlow Condensed",Arial Narrow,sans-serif`; x.font=numFont; x.textAlign='center'; x.textBaseline='middle';
  const starC={}; for(let i=1;i<=5;i++) starC[i]=cssv(SC[i]);
  for(const b of hd.booths){ const ring=b[2]; x.beginPath(); for(let i=0;i<ring.length;i++){ const X=SX(ring[i][0]),Y=SY(ring[i][1]); i?x.lineTo(X,Y):x.moveTo(X,Y); } x.closePath();
    const bo=BOOTH[b[0]]; const [st,sid]=boothStar(bo); const dayOk=!day||bo.ids.some(id=>M(id).d===day); const hi=st>=1&&st>=min&&dayOk;
    let fill=boothC; if(bo.ids.some(id=>M(id).s===-1)) fill=skipC; if(hi) fill=starC[st];
    x.fillStyle=fill; x.fill(); x.strokeStyle=lineC; x.stroke();
    if(showNum){ let minx=1e9,maxx=-1e9; for(const p of ring){ if(p[0]<minx)minx=p[0]; if(p[0]>maxx)maxx=p[0]; } const w=(maxx-minx)*s; if(w>26){ x.fillStyle=hi?'#fff':textC; x.fillText(b[0], SX(bo.cx), SY(bo.cy)-(showName&&b[3]?6:0)); if(showName&&b[3]&&w>60){ x.font=`${Math.max(8,Math.min(12,s*70))}px "IBM Plex Sans",sans-serif`; x.fillText(short(b[3],Math.floor(w/6)), SX(bo.cx), SY(bo.cy)+8); x.font=numFont; } } } }
  if(mapLayers.pois){ const pr=Math.max(4.5,Math.min(9,s*70)); for(const p of hd.pois){ const X=SX(p[1]),Y=SY(p[2]); const glyph={wc:'WC',food:'🍴',cafe:'☕',esc:'⇅',elev:'⇕',stairs:'⤴'}[p[0]]||'•'; x.fillStyle=cssv('--panel'); x.strokeStyle=lineC; x.beginPath(); x.arc(X,Y,pr,0,Math.PI*2); x.fill(); x.stroke(); x.fillStyle=textC; x.font=`bold ${Math.round(pr)}px "IBM Plex Sans",sans-serif`; x.fillText(glyph,X,Y); } }
  if(mapLayers.labels&&s>0.06){ x.fillStyle=cssv('--ink3'); for(const l of hd.labels){ const fs=Math.max(9,Math.min(16,l[3]*s*0.12)); x.font=`600 ${fs}px "Barlow Condensed",sans-serif`; x.save(); x.translate(SX(l[1]),SY(l[2])); x.rotate(-(l[4]||0)*Math.PI/180); x.fillText(l[0].toUpperCase(),0,0); x.restore(); } } }
function drawNow(){ if(cv.width===0) resizeMap(); checkTheme(); const d=dpr(); ctx.setTransform(d,0,0,d,0,0); const W=cv.width/d, Hh=cv.height/d; ctx.fillStyle=cssv('--map-bg'); ctx.fillRect(0,0,W,Hh);
  const hd=H[hall], min=+$('#mapMin').value, day=$('#mapDay').value; const s=view.scale;
  if(stat.key!==staticKey()){ if(!stat.canvas||stat.hall!==hall||!zooming) buildStatic(); } // during an active zoom gesture, reuse the last static image scaled
  const f=s/stat.scale; ctx.imageSmoothingEnabled=f<1; ctx.drawImage(stat.canvas, sx(stat.ox), sy(stat.oy), stat.w*f, stat.h*f);
  const showNum=s>0.12;
  ctx.textAlign='center'; ctx.textBaseline='middle';
  const marked=[];
  for(const b of hd.booths){ const bo=BOOTH[b[0]]; const [st,sid]=boothStar(bo); if(!(st>=1&&st>=min)) continue; const dayOk=!day||bo.ids.some(id=>M(id).d===day); if(!dayOk) continue; marked.push({b,st,sid,vis:sid&&M(sid).v}); }
  // (dynamic overlays follow)
  // marked booths: name tags always visible + visited tick
  ctx.font=`bold ${Math.max(10,Math.min(13,s*80))}px "IBM Plex Sans",sans-serif`;
  for(const m of marked){ const bo=BOOTH[m.b[0]]; const X=sx(bo.cx), Y=sy(bo.cy); const name=short(byId[m.sid].n,22); const tw=ctx.measureText(name).width+10; const ty=Y-(showNum?14:0)-10;
    if(!showNum||s<0.2){ ctx.fillStyle='rgba(0,0,0,.65)'; roundRect(X-tw/2,ty-8,tw,16,4); ctx.fill(); ctx.fillStyle='#fff'; ctx.fillText(name,X,ty); }
    if(m.vis){ ctx.fillStyle=cssv('--ok'); ctx.beginPath(); ctx.arc(X+ (showNum?0:tw/2), Y-(showNum?0:18), 7,0,Math.PI*2); ctx.fill(); ctx.fillStyle='#fff'; ctx.fillText('✓',X+(showNum?0:tw/2),Y-(showNum?0:18)); }
    else { ctx.fillStyle='#fff'; ctx.font=`bold ${Math.max(9,Math.min(12,s*70))}px "Barlow Condensed",sans-serif`; if(!showNum){ ctx.fillText('★'+m.st,X,Y); } ctx.font=`bold ${Math.max(10,Math.min(13,s*80))}px "IBM Plex Sans",sans-serif`; } }
  // route
  if(route&&route.h===hall&&route.path.length){ ctx.strokeStyle=cssv('--accent'); ctx.lineWidth=3; ctx.setLineDash([8,6]); ctx.beginPath(); route.path.forEach((p,i)=>{ const X=sx(p[0]),Y=sy(p[1]); i?ctx.lineTo(X,Y):ctx.moveTo(X,Y); }); ctx.stroke(); ctx.setLineDash([]);
    route.stops.forEach((st,i)=>{ const bo=BOOTH[st.booth]; const X=sx(bo.cx), Y=sy(bo.cy)+ (showNum?16:20); ctx.fillStyle=cssv('--accent'); ctx.beginPath(); ctx.arc(X,Y,9,0,Math.PI*2); ctx.fill(); ctx.fillStyle=cssv('--accent-ink'); ctx.font='bold 11px "Barlow Condensed",sans-serif'; ctx.fillText(String(i+1),X,Y); }); }
  // position
  if(pos&&pos.h===hall){ const X=sx(pos.x),Y=sy(pos.y); if(pos.acc){ ctx.fillStyle='rgba(26,115,232,.15)'; ctx.beginPath(); ctx.arc(X,Y,Math.max(12,pos.acc*39.37*s),0,Math.PI*2); ctx.fill(); }
    ctx.fillStyle='#fff'; ctx.beginPath(); ctx.arc(X,Y,9,0,Math.PI*2); ctx.fill(); ctx.fillStyle=cssv('--gps'); ctx.beginPath(); ctx.arc(X,Y,6,0,Math.PI*2); ctx.fill(); }
  // north arrow (hall CAD frame is rotated relative to true north)
  drawNorth(W-30,Hh-70);
  renderMapStatus(marked); }
function drawNorth(X,Y){ const A=H[hall].A; // north direction in CAD frame: gradient of latitude
  const ang=Math.atan2(A[4],A[3]); // direction (in viewer/CAD axes) of increasing latitude
  ctx.save(); ctx.translate(X,Y); ctx.rotate(-ang+Math.PI/2); ctx.fillStyle=cssv('--ink2'); ctx.beginPath(); ctx.moveTo(0,-14); ctx.lineTo(6,6); ctx.lineTo(0,2); ctx.lineTo(-6,6); ctx.closePath(); ctx.fill(); ctx.restore(); ctx.fillStyle=cssv('--ink2'); ctx.font='bold 10px "IBM Plex Sans",sans-serif'; ctx.textAlign='center'; ctx.fillText('N',X,Y+18); }
function roundRect(x,y,w,h,r){ ctx.beginPath(); ctx.moveTo(x+r,y); ctx.arcTo(x+w,y,x+w,y+h,r); ctx.arcTo(x+w,y+h,x,y+h,r); ctx.arcTo(x,y+h,x,y,r); ctx.arcTo(x,y,x+w,y,r); ctx.closePath(); }
const short=(s,n)=>s.length>n?s.slice(0,n-1)+'…':s;
function renderMapStatus(marked){ const el=$('#mapstatus'); const tot=marked.length, done=marked.filter(m=>m.vis).length; let p=''; if(pos&&pos.h===hall) p=` · you: ${pos.src==='gps'?'GPS ±'+Math.round(pos.acc||0)+' m':'at booth '+pos.booth}`; else if(pos&&pos.h!==hall) p=` · you are in ${H[pos.h].short}`;
  el.innerHTML=`<b>${esc(H[hall].name)}</b> · ${tot} stop${tot!==1?'s':''} shown${tot?` · ${done} visited`:''}${p}`;
  $('#mapleg').innerHTML=`<span class="legend"><span><i style="background:var(--s5)"></i>★5</span><span><i style="background:var(--s4)"></i>★4</span><span><i style="background:var(--s3)"></i>★3</span><span><i style="background:var(--s2)"></i>★2</span><span><i style="background:var(--s1)"></i>★1</span><span><i style="background:var(--panel3)"></i>skip</span><span><i style="background:var(--map-walk);border:1px solid var(--line)"></i>aisle</span></span>`; }
// hall picker
$('#hallpick').innerHTML=HALL_IDS.map(h=>`<button data-h="${h}" class="b-${BLD[h[0]]} ${h===hall?'on':''}">${window.innerWidth<760?esc(H[h].short.replace(/ Building, Level | L/,' ').replace(/^(\w)\w+ /,'$1')):esc(H[h].short)}</button>`).join('');
$('#hallpick').addEventListener('click',e=>{ const b=e.target.closest('button'); if(!b) return; setHall(b.dataset.h); fitHall(); draw(); });
function setHall(h){ hall=h; $$('#hallpick button').forEach(b=>b.classList.toggle('on',b.dataset.h===h)); if(route&&route.h!==h){ route=null; $('#routestrip').hidden=true; $('#clearRoute').hidden=true; } }
$('#zin').onclick=()=>{ view.scale*=1.4; zoomTick(); draw(); }; $('#zout').onclick=()=>{ view.scale/=1.4; zoomTick(); draw(); }; $('#zfit').onclick=()=>{ fitHall(); draw(); };
fillSel($('#mapDay'),DAYS.map(d=>({value:d[0],label:d[1]}))); $('#mapDay').onchange=draw; $('#mapMin').onchange=draw;
// pointer interaction
let ptrs=new Map(), lastDist=0, dragged=false, downPt=null;
cv.addEventListener('pointerdown',e=>{ cv.setPointerCapture(e.pointerId); ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY}); dragged=false; downPt={x:e.clientX,y:e.clientY}; if(ptrs.size===2){ const [a,b]=[...ptrs.values()]; lastDist=Math.hypot(a.x-b.x,a.y-b.y); } });
cv.addEventListener('pointermove',e=>{ if(!ptrs.has(e.pointerId)) return; const prev=ptrs.get(e.pointerId); ptrs.set(e.pointerId,{x:e.clientX,y:e.clientY});
  if(ptrs.size===1){ const dx=e.clientX-prev.x, dy=e.clientY-prev.y; if(Math.abs(e.clientX-downPt.x)+Math.abs(e.clientY-downPt.y)>4) dragged=true; view.cx-=dx/view.scale; view.cy+=dy/view.scale; draw(); }
  else if(ptrs.size===2){ const [a,b]=[...ptrs.values()]; const d=Math.hypot(a.x-b.x,a.y-b.y); if(lastDist){ view.scale*=d/lastDist; zoomTick(); } lastDist=d; dragged=true; draw(); } });
cv.addEventListener('pointerup',e=>{ ptrs.delete(e.pointerId); if(ptrs.size<2) lastDist=0; if(!dragged&&e.button===0) tapMap(e); });
cv.addEventListener('pointercancel',e=>{ ptrs.delete(e.pointerId); });
cv.addEventListener('wheel',e=>{ e.preventDefault(); const rect=cv.getBoundingClientRect(); const mx=e.clientX-rect.left, my=e.clientY-rect.top; const f=e.deltaY<0?1.15:1/1.15; const wx=(mx-cv.width/dpr()/2)/view.scale+view.cx, wy=-(my-cv.height/dpr()/2)/view.scale+view.cy; view.scale*=f; view.cx=wx-(mx-cv.width/dpr()/2)/view.scale; view.cy=wy+(my-cv.height/dpr()/2)/view.scale; zoomTick(); draw(); },{passive:false});
function tapMap(e){ const rect=cv.getBoundingClientRect(); const mx=e.clientX-rect.left, my=e.clientY-rect.top; const wx=(mx-cv.width/dpr()/2)/view.scale+view.cx, wy=-(my-cv.height/dpr()/2)/view.scale+view.cy;
  for(const b of H[hall].booths){ if(pip(wx,wy,b[2])){ const bo=BOOTH[b[0]]; if(bo.ids.length) openSheet(bo.ids[0]); else toast(`Booth ${b[0]} · ${b[3]||'unassigned'}`); return; } } }
function gotoBooth(booth){ const bo=BOOTH[booth]; if(!bo){ toast('Booth '+booth+' is not on the hall maps'); return; } showTab('map'); setHall(bo.h); view.cx=bo.cx; view.cy=bo.cy; view.scale=Math.max(view.scale,0.25); draw(); }
// find on map
let mqT; $('#mapq').addEventListener('input',e=>{ clearTimeout(mqT); mqT=setTimeout(()=>{ const q=e.target.value.trim().toLowerCase(); const pl=$('#poplist'); if(!q){ pl.classList.remove('show'); return; }
  const hits=R.filter(r=>r.n.toLowerCase().includes(q)||r.b.some(b=>b[0].startsWith(q))).slice(0,12); pl.innerHTML=hits.map(r=>`<div data-id="${r.i}" data-b="${esc(r.b[0]?r.b[0][0]:'')}"><b>${esc(r.b[0]?r.b[0][0]:'')}</b>${esc(r.n)} <span class="help">${esc(r.b[0]?r.b[0][1].replace(' Building, Level',' L'):'')}</span></div>`).join('')||'<div>No match</div>'; pl.classList.add('show'); },150); });
$('#poplist').addEventListener('click',e=>{ const d=e.target.closest('[data-id]'); if(!d) return; $('#poplist').classList.remove('show'); $('#mapq').value=''; if(d.dataset.b) gotoBooth(d.dataset.b); openSheet(d.dataset.id); });
// position
function setPosBooth(booth){ const bo=BOOTH[booth]; if(!bo) return; const i=nearestWalkable(bo.h,bo.cx,bo.cy,20); const [x,y]=i>=0?cellXY(bo.h,i):[bo.cx,bo.cy]; pos={h:bo.h,x,y,acc:0,src:'manual',booth}; if(gpsWatch){ navigator.geolocation.clearWatch(gpsWatch); gpsWatch=null; $('#gpsBtn').classList.remove('on'); } setHall(bo.h); draw(); }
$('#hereBtn').onclick=()=>{ const b=prompt('Which booth are you standing at? (booth number)'); if(!b) return; const bn=b.trim(); if(BOOTH[bn]){ setPosBooth(bn); view.cx=BOOTH[bn].cx; view.cy=BOOTH[bn].cy; draw(); toast('Position set at booth '+bn); } else toast('Booth '+bn+' not found'); };
function onGps(p){ const {longitude:lon, latitude:lat, accuracy:acc}=p.coords; let h=hallAt(lon,lat); let note=''; if(!h){ const [nh,d]=nearestHall(lon,lat); h=nh; note=d>400?' (far from the halls — GPS may be off)':' (outside a hall; nearest shown)'; }
  const [x,y]=lonLatToCad(h,lon,lat); pos={h,x,y,acc,src:'gps',lon,lat}; if(h!==hall){ setHall(h); fitHall(); } draw(); $('#syncTxt').textContent; if(note) toast('GPS ±'+Math.round(acc)+' m'+note); }
$('#gpsBtn').onclick=()=>{ if(gpsWatch){ navigator.geolocation.clearWatch(gpsWatch); gpsWatch=null; $('#gpsBtn').classList.remove('on'); toast('GPS off'); return; } if(!navigator.geolocation){ toast('No GPS on this device/browser'); return; }
  $('#gpsBtn').classList.add('on'); toast('Waiting for GPS… indoors this can take a while and be 20–50 m off'); gpsWatch=navigator.geolocation.watchPosition(onGps,err=>{ toast('GPS unavailable: '+err.message); $('#gpsBtn').classList.remove('on'); gpsWatch=null; },{enableHighAccuracy:true,maximumAge:5000,timeout:20000}); };
// routing
function targetsInHall(h,min,day,who){ const out=[]; for(const b of H[h].booths){ const bo=BOOTH[b[0]]; for(const id of bo.ids){ const m=M(id); if(m.s>=1&&m.s>=min&&!m.v&&(!day||m.d===day)&&(!who||who==='me'&&m.a===me||who==='unassigned'&&!m.a)){ out.push({booth:b[0],id,name:byId[id].n,star:m.s}); break; } } } return out; }
function nearestFirst(h,startCell,targets){ const order=[]; let path=[]; let cell=startCell; let rem=targets.slice(); let guard=0;
  while(rem.length&&guard++<400){ const {dist,par}=bfs(h,cell); let best=null,bd=1e9,bc=-1; for(const t of rem){ for(const c of boothCells(h,t.booth)){ const d=dist[c]; if(d>=0&&d<bd){bd=d;best=t;bc=c;} } }
    if(!best){ rem.forEach(t=>order.push(Object.assign({},t,{dist:-1}))); break; } order.push(Object.assign({},best,{dist:bd,cell:bc})); path=path.concat(pathTo(par,bc).map(i=>cellXY(h,i))); rem=rem.filter(t=>t!==best); cell=bc; }
  return {stops:order,path}; }
$('#routeBtn').onclick=()=>{ if(!pos||pos.h!==hall){ toast('Set your position first: tap ◎ for GPS or 📍 to enter the booth you are at'); return; } const t=targetsInHall(hall,+$('#mapMin').value,$('#mapDay').value,''); if(!t.length){ toast('No unvisited stops in this hall at the current star/day filter'); return; }
  const start=nearestWalkable(hall,pos.x,pos.y,30); if(start<0){ toast('Position is outside the walkable area'); return; } const r=nearestFirst(hall,start,t); route=Object.assign({h:hall},r); draw(); $('#clearRoute').hidden=false; const strip=$('#routestrip'); strip.hidden=false; const cs=H[hall].grid.cs;
  strip.innerHTML=r.stops.map((s,i)=>`<div class="st" data-id="${s.id}" data-b="${s.booth}"><b>${i+1}</b>${esc(s.booth)} <span>${esc(short(s.name,22))}</span><span class="sbadge s${s.star}">★${s.star}</span>${s.dist>=0?`<span class="help">${Math.round(s.dist*cs*0.0254)} m</span>`:''}</div>`).join(''); toast(`Route: ${r.stops.length} stops, ≈${Math.round(r.stops.reduce((a,s)=>a+Math.max(0,s.dist),0)*cs*0.0254)} m walking`); };
$('#routestrip').addEventListener('click',e=>{ const d=e.target.closest('.st'); if(!d) return; gotoBooth(d.dataset.b); openSheet(d.dataset.id); });
$('#clearRoute').onclick=()=>{ route=null; $('#routestrip').hidden=true; $('#clearRoute').hidden=true; draw(); };
window.addEventListener('resize',()=>{ if(cur==='map'){ resizeMap(); draw(); } });
if(window.matchMedia){ window.matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{ if(cur==='map') draw(); }); }

// ================= WALK =================
fillSel($('#walkDay'),DAYS.map(d=>({value:d[0],label:d[1]}))); fillSel($('#walkHall'),HALL_IDS.map(h=>({value:h,label:H[h].name})));
['walkDay','walkHall','walkMin','walkWho','walkOrder','walkHide'].forEach(id=>$('#'+id).addEventListener('change',renderWalk));
function renderWalk(){ const day=$('#walkDay').value, hf=$('#walkHall').value, min=+$('#walkMin').value, who=$('#walkWho').value, order=$('#walkOrder').value, hide=$('#walkHide').checked;
  const rows=[]; let total=0,done=0,minLeft=0;
  R.forEach(r=>{ const m=M(r.i); if(!(m.s>=1&&m.s>=min)) return; if(day&&m.d!==day) return; if(who==='me'&&m.a!==me) return; if(who==='unassigned'&&m.a) return;
    r.b.forEach(b=>{ const h=HALL_NAME[b[1]]; if(hf&&h!==hf) return; total++; if(m.v) done++; else minLeft+=estMin(m.s); if(hide&&m.v) return; rows.push({r,b,m,h}); }); });
  $('#walkKpi').innerHTML=`<div class="kpi"><b class="num">${total}</b><span>stops</span></div><div class="kpi"><b class="num">${done}</b><span>visited</span></div><div class="kpi"><b class="num">${total-done}</b><span>remaining</span></div><div class="kpi"><b class="num">${Math.round(minLeft/60*10)/10} h</b><span>est. time left</span></div>`;
  if(!total){ $('#walk').innerHTML='<div class="empty">Nothing to walk yet. Star exhibitors in Explore (★3+ show here by default), or lower the star filter above.</div>'; return; }
  let html=''; const byHall={}; rows.forEach(x=>{ (byHall[x.h||'?']=byHall[x.h||'?']||[]).push(x); });
  const hallOrder=HALL_IDS.filter(h=>byHall[h]); if(pos&&byHall[pos.h]){ hallOrder.splice(hallOrder.indexOf(pos.h),1); hallOrder.unshift(pos.h); }
  for(const h of hallOrder){ let list=byHall[h]; if(order==='near'&&pos&&pos.h===h){ const start=nearestWalkable(h,pos.x,pos.y,30); if(start>=0){ const t=list.map(x=>({booth:x.b[0],id:x.r.i,name:x.r.n,star:x.m.s})); const rr=nearestFirst(h,start,t); const idx={}; rr.stops.forEach((s,i)=>idx[s.booth+'|'+s.id]=i); list=list.slice().sort((a,b)=>(idx[a.b[0]+'|'+a.r.i]??999)-(idx[b.b[0]+'|'+b.r.i]??999)); } } else list=list.slice().sort((a,b)=>a.b[0].localeCompare(b.b[0]));
    const cnt=list.length; html+=`<h2><span class="bar" style="background:var(--${BLD[h[0]]})"></span>${esc(H[h].name)}<span class="pc">${cnt} stop${cnt!==1?'s':''}${order==='near'&&pos&&pos.h===h?' · nearest first from your position':''}</span></h2>`;
    html+=list.map(({r,b,m})=>`<div class="wrow ${m.v?'done':''}" data-id="${r.i}"><input type="checkbox" data-v="${r.i}" ${m.v?'checked':''} aria-label="visited"><div class="wb">${esc(b[0])}<small>${esc(b[2]||'')}</small></div><div><div class="wn">${esc(r.n)}</div><div class="ws">${esc(r.k)}${m.a?' · '+esc(m.a):''}${m.d?' · '+DAYS.find(d=>d[0]===m.d)[1]:''}${m.n?' · <i>'+esc(m.n)+'</i>':''}${m.v&&m.vb?' · ✓ '+esc(m.vb):''}</div></div><span class="sbadge s${m.s}">★${m.s}</span></div>`).join(''); }
  if(!rows.length) html+='<div class="empty">All visited at this filter. Untick "hide visited" to review.</div>';
  $('#walk').innerHTML=html; }
$('#walk').addEventListener('change',e=>{ const c=e.target.closest('input[data-v]'); if(!c) return; setM(c.dataset.v,{v:c.checked,vb:c.checked?me:'',vt:c.checked?Date.now():0}); renderWalk(); });
$('#walk').addEventListener('click',e=>{ if(e.target.closest('input')) return; const w=e.target.closest('.wrow'); if(w) openSheet(w.dataset.id); });

// ================= PLAN =================
fillSel($('#bHall'),HALL_IDS.map(h=>({value:h,label:H[h].name}))); fillSel($('#bDay'),DAYS.map(d=>({value:d[0],label:d[1]}))); fillSel($('#planFilter'),DAYS.map(d=>({value:d[0],label:d[1]})));
['m5','m4','m3','m2','m1','mw'].forEach(id=>$('#'+id).addEventListener('change',()=>{ meta.mins={5:+$('#m5').value,4:+$('#m4').value,3:+$('#m3').value,2:+$('#m2').value,1:+$('#m1').value,w:+$('#mw').value}; setMeta(); renderPlan(); }));
let planDay=''; let alRows=[];
async function renderAdmin(){ const box=$('#adminBox'); if(!allowed||allowed.role!=='admin'){ box.hidden=true; return; } box.hidden=false; const {data}=await sb.from('allowed_emails').select('*').order('added_at'); alRows=data||[];
  $('#alList').innerHTML=alRows.map(r=>`<span class="t" style="display:inline-block;border:1px solid var(--line);border-radius:999px;padding:2px 10px;margin:2px;background:var(--chip)">${esc(r.email)}${r.name?' · '+esc(r.name):''}${r.role==='admin'?' · <b>admin</b>':''} <button data-al="${esc(r.email)}" style="border:0;background:none;color:var(--ink3)" title="Remove access">×</button></span>`).join('')||'Nobody invited yet.'; }
$('#alAdd').onclick=async()=>{ const email=$('#alEmail').value.trim().toLowerCase(), name=$('#alName').value.trim(), role=$('#alRole').value; if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)){ toast('Enter a valid email'); return; } const {error}=await sb.from('allowed_emails').upsert({email,name,role,added_by:session.user.email}); if(error){ toast('Could not invite: '+error.message,4000); return; } $('#alEmail').value=''; $('#alName').value=''; if(name&&!meta.team.includes(name)){ meta.team.push(name); setMeta(); } toast(email+' can now sign in'); renderAdmin(); renderPlan(); };
$('#alList').addEventListener('click',async e=>{ const b=e.target.closest('[data-al]'); if(!b) return; if(b.dataset.al.toLowerCase()===session.user.email.toLowerCase()){ toast('You cannot remove yourself'); return; } if(!confirm('Remove access for '+b.dataset.al+'?')) return; await sb.from('allowed_emails').delete().eq('email',b.dataset.al); renderAdmin(); });
function renderPlan(){ renderAdmin(); const mm=mins(); ['5','4','3','2','1'].forEach(k=>$('#m'+k).value=mm[k]); $('#mw').value=mm.w;
  const stat={}; DAYS.forEach(d=>stat[d[0]]={n:0,min:0,halls:{},done:0}); let un=0;
  R.forEach(r=>{ const m=M(r.i); if(!(m.s>=1)) return; if(!m.d){ un++; return; } const s=stat[m.d]; s.n++; s.min+=estMin(m.s); if(m.v) s.done++; r.halls.forEach(h=>s.halls[h]=(s.halls[h]||0)+1); });
  $('#days').innerHTML=DAYS.map(d=>{ const s=stat[d[0]]; const hrs=s.min/60; return `<div class="day ${planDay===d[0]?'on':''}" data-d="${d[0]}"><h4>${d[1]}</h4><div class="m"><b class="num">${s.n}</b> stops · ≈${Math.round(hrs*10)/10} h${hrs>8?' <span class="warn">— over a show day</span>':''}</div><div class="m">${Object.entries(s.halls).map(([h,n])=>esc(h.replace(' Building, Level',' L'))+' '+n).join(' · ')||'—'}</div><div class="m">${s.done} visited</div></div>`; }).join('')+`<div class="day ${planDay==='0'?'on':''}" data-d="0"><h4>Unassigned</h4><div class="m"><b class="num">${un}</b> starred, no day yet</div></div>`;
  const teamOpts=`<option value="">—</option>`+meta.team.map(t=>`<option>${esc(t)}</option>`).join('');
  $('#bWho').innerHTML=`<option value="">(no person)</option>`+meta.team.map(t=>`<option>${esc(t)}</option>`).join('');
  $('#team').innerHTML=meta.team.map(t=>`<span class="t">${esc(t)}<button data-rm="${esc(t)}" title="Remove">×</button></span>`).join('')||'<span class="help">No names yet — add your team so booths can be assigned.</span>';
  const pf=$('#planFilter').value; const rows=R.filter(r=>{ const m=M(r.i); if(!(m.s>=1)) return false; if(pf==='0') return !m.d; if(pf) return m.d===pf; return true; }).sort((a,b)=>M(b.i).s-M(a.i).s||(a.b[0]?a.b[0][0]:'').localeCompare(b.b[0]?b.b[0][0]:''));
  $('#planBody').innerHTML=rows.map(r=>{ const m=M(r.i); return `<tr data-id="${r.i}"><td><span class="sbadge s${m.s}">★${m.s}</span></td><td class="cond" style="font-weight:700;font-size:16px">${esc(r.b.map(b=>b[0]).join(', '))}</td><td><a href="#" data-open="${r.i}" style="color:inherit;font-weight:600;text-decoration:none">${esc(r.n)}</a></td><td style="font-size:12px">${esc(r.halls.map(h=>h.replace(' Building, Level',' L')).join(', '))}</td><td><select data-day="${r.i}"><option value="">—</option>${DAYS.map(d=>`<option value="${d[0]}" ${m.d===d[0]?'selected':''}>${d[1]}</option>`).join('')}</select></td><td><select data-who="${r.i}">${teamOpts.replace(`<option>${esc(m.a)}</option>`,`<option selected>${esc(m.a)}</option>`)}</select></td><td>${m.v?'✓':''}</td></tr>`; }).join('')||'<tr><td colspan="7" class="help">No starred exhibitors yet.</td></tr>';
  const bh=$('#bHall').value, bs=+$('#bStar').value; const cand=R.filter(r=>{ const m=M(r.i); return m.s>=bs&&!m.d&&(!bh||r.hallIds.includes(bh)); }); $('#bInfo').textContent=`${cand.length} match`; }
$('#days').addEventListener('click',e=>{ const d=e.target.closest('.day'); if(!d) return; planDay=planDay===d.dataset.d?'':d.dataset.d; $('#planFilter').value=planDay; renderPlan(); });
$('#planFilter').addEventListener('change',e=>{ planDay=e.target.value; renderPlan(); });
['bHall','bStar'].forEach(id=>$('#'+id).addEventListener('change',renderPlan));
$('#bApply').onclick=()=>{ const bh=$('#bHall').value, bs=+$('#bStar').value, bd=$('#bDay').value, bw=$('#bWho').value; let n=0; R.forEach(r=>{ const m=M(r.i); if(m.s>=bs&&!m.d&&(!bh||r.hallIds.includes(bh))){ setM(r.i,{d:bd,a:bw||m.a}); n++; } }); toast(`Assigned ${n} exhibitors to ${DAYS.find(d=>d[0]===bd)[1]}`); renderPlan(); };
$('#planBody').addEventListener('change',e=>{ const d=e.target.closest('[data-day]'); if(d){ setM(d.dataset.day,{d:d.value}); renderPlan(); return; } const w=e.target.closest('[data-who]'); if(w){ setM(w.dataset.who,{a:w.value}); renderPlan(); } });
$('#planBody').addEventListener('click',e=>{ const a=e.target.closest('[data-open]'); if(a){ e.preventDefault(); openSheet(a.dataset.open); } });
$('#teamAddBtn').onclick=()=>{ const v=$('#teamAdd').value.trim(); if(!v) return; if(!meta.team.includes(v)) meta.team.push(v); setMeta(); $('#teamAdd').value=''; renderPlan(); };
$('#team').addEventListener('click',e=>{ const b=e.target.closest('[data-rm]'); if(!b) return; meta.team=meta.team.filter(t=>t!==b.dataset.rm); setMeta(); renderPlan(); });

// ================= HALLS =================
const cc=$('#campus'), cctx=cc.getContext('2d'); let campusPos=null;
function renderHalls(){ const byHall={}; R.forEach(r=>r.b.forEach(b=>{ const h=b[1]; if(!byHall[h]) byHall[h]={n:0,secs:{},s5:0,s4:0,s3:0,s2:0,s1:0,v:0}; const s=byHall[h]; s.n++; if(b[2]) s.secs[b[2]]=(s.secs[b[2]]||0)+1; const m=M(r.i); if(m.s>=1) s['s'+m.s]++; if(m.v) s.v++; }));
  $('#hallgrid').innerHTML=HALL_IDS.map(h=>{ const s=byHall[H[h].name]||{n:0,secs:{},s5:0,s4:0,s3:0,s2:0,s1:0,v:0}; const secs=Object.entries(s.secs).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${esc(k)} <b>${v}</b>`).join(' · ');
    return `<div class="hcard" style="border-top-color:var(--${BLD[h[0]]})" data-h="${h}"><h3>${esc(H[h].name)}</h3><div class="kv"><span>Booths</span><b class="num">${s.n}</b><span>Starred ★5 / ★4 / ★3 / ★2 / ★1</span><b class="num"><span style="color:var(--s5)">${s.s5}</span> / <span style="color:var(--s4)">${s.s4}</span> / <span style="color:var(--s3)">${s.s3}</span> / <span style="color:var(--s2)">${s.s2}</span> / <span style="color:var(--s1)">${s.s1}</span></b><span>Visited</span><b class="num">${s.v}</b></div><div class="secs">${secs}</div></div>`; }).join('');
  drawCampus(); }
$('#hallgrid').addEventListener('click',e=>{ const c=e.target.closest('.hcard'); if(!c) return; showTab('map'); setHall(c.dataset.h); fitHall(); draw(); });
function drawCampus(){ const W=cc.width, Hh=cc.height; cctx.setTransform(1,0,0,1,0,0); cctx.fillStyle=cssv('--map-bg'); cctx.fillRect(0,0,W,Hh);
  const pts=HALL_IDS.flatMap(h=>H[h].geofence); const lons=pts.map(p=>p[0]), lats=pts.map(p=>p[1]); const lon0=Math.min(...lons), lon1=Math.max(...lons), lat0=Math.min(...lats), lat1=Math.max(...lats); const kx=82000, ky=111000; // m per degree approx at 41.85N
  const mw=(lon1-lon0)*kx, mh=(lat1-lat0)*ky; const sc=Math.min((W-40)/mw,(Hh-40)/mh); const X=lon=>20+(lon-lon0)*kx*sc, Y=lat=>Hh-20-(lat-lat0)*ky*sc;
  for(const h of HALL_IDS){ const gf=H[h].geofence; cctx.beginPath(); gf.forEach((p,i)=>{ i?cctx.lineTo(X(p[0]),Y(p[1])):cctx.moveTo(X(p[0]),Y(p[1])); }); cctx.closePath(); cctx.fillStyle=cssv('--'+BLD[h[0]]); cctx.globalAlpha=.35; cctx.fill(); cctx.globalAlpha=1; cctx.strokeStyle=cssv('--'+BLD[h[0]]); cctx.lineWidth=2; cctx.stroke();
    let cx=0,cy=0; gf.forEach(p=>{cx+=p[0];cy+=p[1];}); cx/=gf.length; cy/=gf.length; cctx.fillStyle=cssv('--ink'); cctx.font='bold 13px "Barlow Condensed",sans-serif'; cctx.textAlign='center'; cctx.fillText(H[h].short.toUpperCase(),X(cx),Y(cy)); }
  if(campusPos){ cctx.fillStyle='#fff'; cctx.beginPath(); cctx.arc(X(campusPos[0]),Y(campusPos[1]),8,0,Math.PI*2); cctx.fill(); cctx.fillStyle=cssv('--gps'); cctx.beginPath(); cctx.arc(X(campusPos[0]),Y(campusPos[1]),5,0,Math.PI*2); cctx.fill(); }
  cctx.fillStyle=cssv('--ink2'); cctx.font='bold 11px "IBM Plex Sans",sans-serif'; cctx.textAlign='left'; cctx.fillText('N ↑  ·  Lake Michigan to the east',26,18); }
$('#campusGps').onclick=()=>{ if(!navigator.geolocation){ toast('No GPS available'); return; } toast('Getting position…'); navigator.geolocation.getCurrentPosition(p=>{ const lon=p.coords.longitude, lat=p.coords.latitude; campusPos=[lon,lat]; const h=hallAt(lon,lat); const [nh,d]=nearestHall(lon,lat); drawCampus(); toast(h?`You are in ${H[h].name} (±${Math.round(p.coords.accuracy)} m)`:`Nearest hall: ${H[nh].name}, ~${Math.round(d)} m away (±${Math.round(p.coords.accuracy)} m)`); },err=>toast('GPS unavailable: '+err.message),{enableHighAccuracy:true,timeout:20000}); };

// ================= PLAN CODE (transfer without sync) =================
function b64u(s){ return btoa(unescape(encodeURIComponent(s))); } function unb64u(s){ return decodeURIComponent(escape(atob(s))); }
$('#codeOut').onclick=async()=>{ const code='IMTS26:'+b64u(JSON.stringify({marks,meta})); try{ await navigator.clipboard.writeText(code); toast(`Plan code copied (${Object.keys(marks).length} marks) — paste it to a colleague`); }catch(e){ prompt('Copy this plan code:',code); } };
$('#codeIn').onclick=()=>{ const s=prompt('Paste a plan code (IMTS26:…). It merges into your plan — newer edits win.'); if(!s) return; try{ const j=JSON.parse(unb64u(s.trim().replace(/^IMTS26:/,''))); const n=Object.keys(j.marks||{}).length; mergeIn(j.marks||{}, j.meta); Object.keys(j.marks||{}).forEach(id=>pending.add(id)); pending.add('meta'); persist(); renderAll(); toast(`Merged ${n} marks from plan code`); }catch(e){ toast('That does not look like a valid plan code'); } };
$('#helpBtn').onclick=()=>{ $('#help').classList.add('open'); }; $('#helpClose').onclick=()=>$('#help').classList.remove('open'); $('#helpBg').onclick=()=>$('#help').classList.remove('open');
try{ if(!localStorage.getItem('imts26-seen')){ $('#help').classList.add('open'); localStorage.setItem('imts26-seen','1'); } }catch(e){}
// ================= RECORDER =================
let recState=null; // {r, stream, mr, chunks, start, paused, pausedMs, pauseAt, timer, wake, ctx, analyser, raf}
const fmt=s=>String(Math.floor(s/60)).padStart(2,'0')+':'+String(Math.floor(s%60)).padStart(2,'0');
function pickMime(){ const c=['audio/webm;codecs=opus','audio/webm','audio/mp4','audio/ogg;codecs=opus','audio/mpeg']; for(const m of c){ if(window.MediaRecorder&&MediaRecorder.isTypeSupported(m)) return m; } return ''; }
function startRecorder(r){ if(!window.MediaRecorder||!navigator.mediaDevices){ toast('This browser cannot record audio. Use Chrome (Android) or Safari (iPhone).',4000); return; }
  closeSheet(); recState={r,chunks:[],paused:false,pausedMs:0}; $('#recTitle').textContent=r.n; $('#recSub').textContent='Booth '+(r.b[0]?r.b[0][0]:'')+' · '+(r.b[0]?r.b[0][1]:''); $('#consentChk').checked=false; $('#consentBox').style.display=''; $('#recMain').disabled=true; $('#recMain').textContent='●'; $('#recMain').classList.remove('pulse'); $('#recPause').disabled=true; $('#recTimer').textContent='00:00'; $('#recStatus').textContent=''; $('#recLvl').style.width='0'; $('#rec').classList.add('open'); }
$('#consentChk').addEventListener('change',e=>{ $('#recMain').disabled=!e.target.checked; });
$('#recCancel').onclick=()=>{ if(recState&&recState.mr&&recState.mr.state!=='inactive'){ if(!confirm('Discard this recording?')) return; recState.discard=true; recState.mr.stop(); } stopTracks(); $('#rec').classList.remove('open'); recState=null; };
function stopTracks(){ if(!recState) return; try{ recState.stream&&recState.stream.getTracks().forEach(t=>t.stop()); }catch(e){} try{ recState.wake&&recState.wake.release(); }catch(e){} cancelAnimationFrame(recState.raf); clearInterval(recState.timer); try{ recState.ctx&&recState.ctx.close(); }catch(e){} }
$('#recMain').onclick=async()=>{ const st=recState; if(!st) return;
  if(!st.mr){ // start
    try{ st.stream=await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true,noiseSuppression:true,autoGainControl:true}}); }catch(e){ $('#recStatus').textContent='Microphone blocked: '+e.message; return; }
    const mime=pickMime(); st.mime=mime||'audio/webm'; st.mr=new MediaRecorder(st.stream, mime?{mimeType:mime,audioBitsPerSecond:48000}:undefined);
    st.mr.ondataavailable=e=>{ if(e.data&&e.data.size) st.chunks.push(e.data); };
    st.mr.onstop=()=>{ if(st.discard) return; finishRecording(st); };
    st.mr.start(10000); st.start=Date.now(); $('#consentBox').style.display='none'; $('#recMain').textContent='■'; $('#recMain').classList.add('pulse'); $('#recPause').disabled=false; $('#recStatus').textContent='Recording… keep the phone screen on.';
    try{ st.wake=await navigator.wakeLock.request('screen'); }catch(e){}
    try{ st.ctx=new (window.AudioContext||window.webkitAudioContext)(); const src=st.ctx.createMediaStreamSource(st.stream); st.analyser=st.ctx.createAnalyser(); st.analyser.fftSize=512; src.connect(st.analyser); const buf=new Uint8Array(st.analyser.frequencyBinCount); const tick=()=>{ st.analyser.getByteTimeDomainData(buf); let s=0; for(const v of buf){ const d=(v-128)/128; s+=d*d; } const rms=Math.sqrt(s/buf.length); $('#recLvl').style.width=Math.min(100,rms*300)+'%'; st.raf=requestAnimationFrame(tick); }; tick(); }catch(e){}
    st.timer=setInterval(()=>{ if(!st.paused) $('#recTimer').textContent=fmt((Date.now()-st.start-st.pausedMs)/1000); },500);
  } else { // stop
    $('#recMain').disabled=true; $('#recPause').disabled=true; $('#recStatus').textContent='Finishing…'; st.mr.stop(); } };
$('#recPause').onclick=()=>{ const st=recState; if(!st||!st.mr) return; if(st.mr.state==='recording'){ st.mr.pause(); st.paused=true; st.pauseAt=Date.now(); $('#recPause').textContent='▶'; $('#recStatus').textContent='Paused'; } else if(st.mr.state==='paused'){ st.mr.resume(); st.paused=false; st.pausedMs+=Date.now()-st.pauseAt; $('#recPause').textContent='⏸'; $('#recStatus').textContent='Recording…'; } };
async function finishRecording(st){ stopTracks(); const dur=Math.round((Date.now()-st.start-st.pausedMs)/1000); const blob=new Blob(st.chunks,{type:st.mime}); const r=st.r;
  if(blob.size<2000){ $('#recStatus').textContent='Nothing was recorded.'; setTimeout(()=>$('#rec').classList.remove('open'),1500); return; }
  $('#recStatus').textContent='Uploading '+(blob.size/1e6).toFixed(1)+' MB…';
  const ext=st.mime.includes('mp4')?'m4a':st.mime.includes('ogg')?'ogg':st.mime.includes('mpeg')?'mp3':'webm';
  try{
    const {data:ins,error:e1}=await sb.from('recordings').insert({exh_id:r.i,exh_name:r.n,booth:r.b[0]?r.b[0][0]:'',user_id:session.user.id,user_email:session.user.email,user_name:me,mime:st.mime.split(';')[0],duration_s:dur,size_bytes:blob.size,consent:true,status:'uploading'}).select().single(); if(e1) throw e1;
    const path=session.user.id+'/'+ins.id+'.'+ext;
    const {error:e2}=await sb.storage.from('recordings').upload(path,blob,{contentType:st.mime.split(';')[0],upsert:true}); if(e2) throw e2;
    await sb.from('recordings').update({path,status:'uploaded'}).eq('id',ins.id);
    $('#recStatus').textContent='Uploaded. Transcribing and writing minutes — this takes about a minute. You can keep walking; the minutes will appear under Meetings and in your email.';
    setM(r.i,{v:true,vb:me,vt:Date.now()});
    setTimeout(()=>{ $('#rec').classList.remove('open'); recState=null; showTab('meet'); },2500);
    loadRecordings(); processRecording(ins.id);
  }catch(e){ $('#recStatus').textContent='Upload failed: '+e.message+'. The recording is kept on this device — press retry.'; keepLocalBlob(r,blob,st.mime,dur); $('#recMain').textContent='↻'; $('#recMain').disabled=false; $('#recMain').onclick=()=>finishRecording(st); }
}
function keepLocalBlob(r,blob,mime,dur){ try{ const req=indexedDB.open('imts26',1); req.onupgradeneeded=()=>req.result.createObjectStore('pend',{keyPath:'id'}); req.onsuccess=()=>{ const tx=req.result.transaction('pend','readwrite'); tx.objectStore('pend').put({id:Date.now(),exh:r.i,blob,mime,dur}); }; }catch(e){} }
async function processRecording(id){ try{ const j=await api('/api/process',{recordingId:id}); if(j.status==='done'){ toast('Minutes ready for '+((recordings.find(x=>x.id===id)||{}).exh_name||'the booth')+(j.emailed?' — emailed to you':''),4000); } }catch(e){ toast('Transcription failed: '+e.message,5000); } loadRecordings(); }

// ================= MEETINGS =================
let recordings=[];
async function loadRecordings(){ if(!sb||!session) return; const {data}=await sb.from('recordings').select('id,exh_id,exh_name,booth,user_email,user_name,duration_s,status,minutes,error,created_at,emailed_at').order('created_at',{ascending:false}).limit(500); if(data){ recordings=data; if(cur==='meet') renderMeet(); if(sheetId&&$('#shMeet')) $('#shMeet').innerHTML=meetListHTML(recordingsFor(sheetId)); } }
const recordingsFor=id=>recordings.filter(x=>x.exh_id===id);
function meetListHTML(list){ if(!list.length) return ''; return `<div style="margin-top:8px"><span class="lbl">Meetings recorded here</span>`+list.map(x=>`<div class="mrow" data-rec="${x.id}"><div><div class="mt">${new Date(x.created_at).toLocaleString('en-US',{timeZone:'America/Chicago',month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'})} · ${esc(x.user_name||x.user_email||'')}</div><div class="ms">${x.minutes&&x.minutes.summary?esc(x.minutes.summary.slice(0,140))+(x.minutes.summary.length>140?'…':''):(x.error?esc(x.error):'')}</div></div><span class="st ${x.status}">${x.status}</span></div>`).join('')+'</div>'; }
function renderMeet(){ const who=$('#meetWho').value, q=$('#meetQ').value.trim().toLowerCase(); let list=recordings.filter(x=>(!who||who!=='me'||x.user_email===session.user.email)&&(!q||(x.exh_name||'').toLowerCase().includes(q)||JSON.stringify(x.minutes||{}).toLowerCase().includes(q)));
  $('#meetList').innerHTML=list.map(x=>`<div class="mrow" data-rec="${x.id}"><div><div class="mt">${esc(x.exh_name||'')} <span class="help">· booth ${esc(x.booth||'')}</span></div><div class="ms">${new Date(x.created_at).toLocaleString('en-US',{timeZone:'America/Chicago',weekday:'short',hour:'2-digit',minute:'2-digit'})} · ${esc(x.user_name||x.user_email||'')}${x.duration_s?' · '+Math.round(x.duration_s/60)+' min':''}${x.emailed_at?' · ✉ sent':''}</div><div class="ms">${x.minutes&&x.minutes.summary?esc(x.minutes.summary.slice(0,180))+(x.minutes.summary.length>180?'…':''):(x.error?'<span style="color:var(--accent)">'+esc(x.error)+'</span>':'')}</div></div><span class="st ${x.status}">${x.status}</span></div>`).join('')||'<div class="empty">No meetings recorded yet. Open an exhibitor and press "Record conversation".</div>'; }
['meetWho','meetQ'].forEach(id=>$('#'+id).addEventListener('input',renderMeet));
$('#meetList').addEventListener('click',e=>{ const d=e.target.closest('[data-rec]'); if(d) openMeeting(d.dataset.rec); });
async function openMeeting(id){ const {data:x}=await sb.from('recordings').select('*').eq('id',id).maybeSingle(); if(!x){ toast('Recording not found'); return; } const m=x.minutes||{}; const list=(arr,f)=>(arr&&arr.length)?'<ul>'+arr.map(v=>`<li>${f?f(v):esc(v)}</li>`).join('')+'</ul>':'<p class="help">—</p>';
  const mine=x.user_id===session.user.id||allowed.role==='admin';
  $('#sheetPanel').innerHTML=`<button class="close" id="sheetClose" aria-label="Close">×</button><h2>${esc(x.exh_name||'')}</h2><div class="help">Booth ${esc(x.booth||'')} · ${new Date(x.created_at).toLocaleString('en-US',{timeZone:'America/Chicago',dateStyle:'medium',timeStyle:'short'})} Chicago · ${esc(x.user_name||x.user_email||'')}${x.duration_s?' · '+Math.round(x.duration_s/60)+' min':''} · <span class="st ${x.status}">${x.status}</span></div>
    <div class="actions" style="margin:10px 0">${x.exh_id?`<button class="btn sm" id="mOpenExh">Open exhibitor</button>`:''}${x.status==='done'?`<button class="btn sm" id="mEmail">✉ Email me the minutes</button>`:''}${(x.status==='error'||x.status==='uploaded')&&mine?`<button class="btn sm primary" id="mRetry">↻ Transcribe again</button>`:''}${mine?`<button class="btn sm" id="mDel">Delete</button>`:''}</div>
    ${x.status==='done'?`<div class="minutes"><h2>Summary</h2><p>${esc(m.summary||'')}</p><h2>People met</h2>${list(m.participants,p=>esc(typeof p==='string'?p:[p.name,p.role,p.company].filter(Boolean).join(' — ')))}<h2>Products / technology</h2>${list(m.products)}<h2>Commercial points</h2>${list(m.commercial)}<h2>They committed to</h2>${list(m.commitments_theirs)}<h2>We committed to</h2>${list(m.commitments_ours)}<h2>Follow-ups</h2>${list(m.followups,f=>esc(typeof f==='string'?f:`${f.what}${f.owner?' — '+f.owner:''}${f.when?' ('+f.when+')':''}`))}<h2>Open questions</h2>${list(m.questions_next)}${m.fit?`<h2>Relevance to us</h2><p>${esc(m.fit)}</p>`:''}<h2>Transcript${m.language?' · '+esc(m.language):''}</h2><div class="tx">${(x.transcript||[]).map(l=>`<div><span class="help">${esc(l.t)}</span> <b>${esc(l.speaker)}:</b> ${esc(l.text)}</div>`).join('')||'—'}</div></div>`
      :x.status==='error'?`<p style="color:var(--accent)">${esc(x.error||'Failed')}</p>`:`<p class="help">Transcription in progress — usually about a minute per 10 minutes of audio. This page updates itself.</p>`}`;
  $('#sheet').classList.add('open'); $('#sheetClose').onclick=closeSheet;
  const oe=$('#mOpenExh'); if(oe) oe.onclick=()=>openSheet(x.exh_id);
  const me_=$('#mEmail'); if(me_) me_.onclick=async()=>{ me_.disabled=true; try{ await api('/api/email',{recordingId:x.id}); toast('Minutes emailed to '+session.user.email); }catch(e){ toast('Email failed: '+e.message,5000); } me_.disabled=false; };
  const rt=$('#mRetry'); if(rt) rt.onclick=async()=>{ rt.disabled=true; toast('Transcribing…'); await processRecording(x.id); openMeeting(x.id); };
  const dl=$('#mDel'); if(dl) dl.onclick=async()=>{ if(!confirm('Delete this recording and its minutes?')) return; if(x.path) await sb.storage.from('recordings').remove([x.path]); await sb.from('recordings').delete().eq('id',x.id); closeSheet(); loadRecordings(); };
}
// deep link from email: #rec=<id>
window.addEventListener('hashchange',()=>{ const m=location.hash.match(/rec=([\w-]+)/); if(m&&session) openMeeting(m[1]); });

// ================= INIT =================
renderList();
if('serviceWorker' in navigator){ navigator.serviceWorker.register('/sw.js').catch(()=>{}); }
boot().then(()=>{ const m=location.hash.match(/rec=([\w-]+)/); if(m&&session) setTimeout(()=>openMeeting(m[1]),800); });
})();
