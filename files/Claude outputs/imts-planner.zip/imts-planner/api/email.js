// POST /api/email { recordingId, to?: string, cc?: string[] } — (re)send the minutes of a processed recording.
import { Resend } from 'resend';
import { requireUser, readJson, env, minutesHtml, esc } from './_lib.js';

export async function sendMinutesEmail(rec, { to, cc = [] }) {
  const resend = new Resend(env('RESEND_API_KEY'));
  const from = process.env.MAIL_FROM || 'IMTS Planner <imts@precinova.com>';
  const subject = `IMTS minutes · ${rec.exh_name || 'Exhibitor'} · booth ${rec.booth || ''}`.trim();
  const html = minutesHtml(rec, process.env.APP_URL);
  const transcript = (rec.transcript || []).map(l => `[${l.t}] ${l.speaker}: ${l.text}`).join('\n');
  const { error } = await resend.emails.send({ from, to: [to].filter(Boolean), cc: (cc || []).filter(Boolean), subject,
    html: html + (transcript ? `<details style="font-family:Arial,sans-serif;max-width:680px;margin:18px auto 0;color:#444"><summary style="cursor:pointer;font-weight:bold">Full transcript</summary><pre style="white-space:pre-wrap;font-size:12px;line-height:1.4">${esc(transcript)}</pre></details>` : ''),
    text: `${subject}\n\n${(rec.minutes && rec.minutes.summary) || ''}\n\n${transcript}` });
  if (error) throw new Error(error.message || JSON.stringify(error));
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  let ctx; try { ctx = await requireUser(req); } catch (e) { return res.status(e.status || 500).json({ error: e.message }); }
  const { admin, user, allowed } = ctx;
  let body; try { body = await readJson(req); } catch (e) { return res.status(400).json({ error: 'Bad JSON' }); }
  const { data: rec } = await admin.from('recordings').select('*').eq('id', body.recordingId || '').maybeSingle();
  if (!rec) return res.status(404).json({ error: 'Recording not found' });
  if (rec.user_id !== user.id && allowed.role !== 'admin') return res.status(403).json({ error: 'Not your recording' });
  if (rec.status !== 'done') return res.status(409).json({ error: 'Minutes are not ready yet' });
  if (!process.env.RESEND_API_KEY) return res.status(503).json({ error: 'Email is not configured (RESEND_API_KEY missing)' });
  try { await sendMinutesEmail(rec, { to: body.to || rec.user_email, cc: body.cc || [] }); await admin.from('recordings').update({ emailed_at: new Date().toISOString() }).eq('id', rec.id); return res.status(200).json({ ok: true }); }
  catch (e) { return res.status(500).json({ error: String(e?.message || e) }); }
}
