import { createClient } from '@supabase/supabase-js';

export function env(name, fallback) {
  const v = process.env[name];
  if (v === undefined || v === '') { if (fallback !== undefined) return fallback; throw new Error(`Missing environment variable ${name}`); }
  return v;
}

export function adminClient() {
  return createClient(env('SUPABASE_URL'), env('SUPABASE_SERVICE_ROLE_KEY'), { auth: { persistSession: false, autoRefreshToken: false } });
}

/** Verify the caller's Supabase JWT and allow-list membership. Returns {user, allowed:{email,role,name}} or throws {status,message}. */
export async function requireUser(req) {
  const auth = req.headers['authorization'] || '';
  const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) throw Object.assign(new Error('Not signed in'), { status: 401 });
  const anon = createClient(env('SUPABASE_URL'), env('SUPABASE_ANON_KEY'), { auth: { persistSession: false, autoRefreshToken: false } });
  const { data, error } = await anon.auth.getUser(token);
  if (error || !data?.user) throw Object.assign(new Error('Invalid session'), { status: 401 });
  const user = data.user;
  const admin = adminClient();
  const { data: allowed } = await admin.from('allowed_emails').select('email,role,name').ilike('email', user.email || '').maybeSingle();
  if (!allowed) throw Object.assign(new Error('This account has not been invited'), { status: 403 });
  return { user, allowed, admin };
}

export function readJson(req) {
  return new Promise((resolve, reject) => {
    if (req.body && typeof req.body === 'object') return resolve(req.body);
    let s = ''; req.on('data', c => s += c); req.on('end', () => { try { resolve(s ? JSON.parse(s) : {}); } catch (e) { reject(e); } }); req.on('error', reject);
  });
}

export function esc(s) { return String(s ?? '').replace(/[&<>"]/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c])); }

/** Render structured minutes to HTML (used for email and the app). */
export function minutesHtml(rec, appUrl) {
  const m = rec.minutes || {}; const list = (arr, f) => (arr && arr.length) ? '<ul>' + arr.map(x => `<li>${f ? f(x) : esc(x)}</li>`).join('') + '</ul>' : '<p style="color:#777">—</p>';
  const when = new Date(rec.created_at).toLocaleString('en-US', { timeZone: 'America/Chicago', dateStyle: 'medium', timeStyle: 'short' });
  return `<div style="font-family:Arial,Helvetica,sans-serif;max-width:680px;margin:0 auto;color:#1b2026;line-height:1.45">
  <div style="border-left:5px solid #D9481C;padding:6px 12px;margin-bottom:14px"><div style="font-size:12px;letter-spacing:1px;text-transform:uppercase;color:#777">IMTS 2026 · Booth meeting minutes</div>
  <h1 style="margin:2px 0 4px;font-size:22px">${esc(rec.exh_name || 'Unknown exhibitor')}</h1>
  <div style="color:#555">Booth ${esc(rec.booth || '—')} · ${when} Chicago · recorded by ${esc(rec.user_name || rec.user_email || '')}${rec.duration_s ? ' · ' + Math.round(rec.duration_s / 60) + ' min' : ''}</div></div>
  <h2 style="font-size:16px;margin:16px 0 4px">Summary</h2><p>${esc(m.summary || '')}</p>
  <h2 style="font-size:16px;margin:16px 0 4px">People met</h2>${list(m.participants, p => esc(typeof p === 'string' ? p : [p.name, p.role, p.company].filter(Boolean).join(' — ')))}
  <h2 style="font-size:16px;margin:16px 0 4px">Products / technology discussed</h2>${list(m.products)}
  <h2 style="font-size:16px;margin:16px 0 4px">Commercial points (prices, lead times, terms)</h2>${list(m.commercial)}
  <h2 style="font-size:16px;margin:16px 0 4px">They committed to</h2>${list(m.commitments_theirs)}
  <h2 style="font-size:16px;margin:16px 0 4px">We committed to</h2>${list(m.commitments_ours)}
  <h2 style="font-size:16px;margin:16px 0 4px">Follow-ups</h2>${list(m.followups, f => esc(typeof f === 'string' ? f : `${f.what}${f.owner ? ' — ' + f.owner : ''}${f.when ? ' (' + f.when + ')' : ''}`))}
  <h2 style="font-size:16px;margin:16px 0 4px">Open questions for next contact</h2>${list(m.questions_next)}
  ${m.fit ? `<h2 style="font-size:16px;margin:16px 0 4px">Relevance to us</h2><p>${esc(m.fit)}</p>` : ''}
  ${appUrl ? `<p style="margin-top:22px"><a href="${esc(appUrl)}#rec=${esc(rec.id)}" style="background:#D9481C;color:#fff;text-decoration:none;padding:9px 14px;border-radius:6px;display:inline-block">Open in the planner (full transcript)</a></p>` : ''}
  <p style="color:#999;font-size:11px;margin-top:26px">Generated automatically from an audio recording made with the participants' consent. Check figures against the exhibitor's written quotation before relying on them.</p></div>`;
}
