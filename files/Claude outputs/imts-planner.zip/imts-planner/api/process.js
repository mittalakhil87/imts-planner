// POST /api/process  { recordingId }
// Downloads the audio from Supabase Storage, sends it to Gemini for a diarised transcript + structured minutes,
// stores the result on the recording row, and emails the minutes to the recorder (and optional CC list).
import { GoogleGenAI } from '@google/genai';
import { requireUser, readJson, env, minutesHtml } from './_lib.js';
import { sendMinutesEmail } from './email.js';

export const config = { maxDuration: 300 };

const SCHEMA = {
  type: 'object',
  properties: {
    language: { type: 'string', description: 'Main language(s) spoken, e.g. "English", "Hindi/English"' },
    transcript: { type: 'array', items: { type: 'object', properties: { t: { type: 'string', description: 'mm:ss' }, speaker: { type: 'string' }, text: { type: 'string' } }, required: ['t', 'speaker', 'text'] } },
    minutes: { type: 'object', properties: {
      summary: { type: 'string' },
      participants: { type: 'array', items: { type: 'object', properties: { name: { type: 'string' }, role: { type: 'string' }, company: { type: 'string' } } } },
      products: { type: 'array', items: { type: 'string' } },
      commercial: { type: 'array', items: { type: 'string' } },
      commitments_theirs: { type: 'array', items: { type: 'string' } },
      commitments_ours: { type: 'array', items: { type: 'string' } },
      followups: { type: 'array', items: { type: 'object', properties: { what: { type: 'string' }, owner: { type: 'string' }, when: { type: 'string' } }, required: ['what'] } },
      questions_next: { type: 'array', items: { type: 'string' } },
      fit: { type: 'string', description: 'One or two sentences on how relevant this exhibitor is to the recorder’s business, based only on what was said' }
    }, required: ['summary', 'participants', 'products', 'commercial', 'commitments_theirs', 'commitments_ours', 'followups', 'questions_next'] }
  },
  required: ['transcript', 'minutes']
};

function prompt(rec) {
  return `You are the note-taker for a business visitor at IMTS 2026 (International Manufacturing Technology Show, Chicago).
The attached audio is a conversation recorded at the booth of "${rec.exh_name || 'an exhibitor'}" (booth ${rec.booth || 'unknown'}). The recorder is ${rec.user_name || 'the visitor'} from Precinova / Blue Photon India (precision workholding — UV-adhesive, thermal-adhesive, ice clamping, vacuum, zero-point; surface finishing / magnetic polishing; precision manufacturing consulting; LabLink Instruments for lab and microscopy equipment).
Speech may mix English and Hindi; transcribe Hindi parts in English translation in square brackets after the original if they carry business meaning, otherwise translate to English.
1) Produce a clean transcript with timestamps (mm:ss), labelling speakers by role when names are unknown (e.g. "Visitor", "Vendor 1", "Vendor 2"). Skip filler; keep every number, price, lead time, model name, spec and commitment exactly as spoken.
2) Produce minutes strictly from what was said — never invent details. Put prices, MOQ, lead times, warranty and payment terms under "commercial". Distinguish what THEY promised (send quote, samples, demo, catalogue) from what WE promised. Follow-ups must be actionable with an owner where stated. "questions_next" = things that were left unanswered or that the visitor should ask on a next call.
Return JSON matching the schema.`;
}

async function transcribeWithGemini(audioBuf, mime, rec) {
  const ai = new GoogleGenAI({ apiKey: env('GEMINI_API_KEY') });
  const model = process.env.GEMINI_MODEL || 'gemini-2.5-flash';
  // Files API handles long audio (up to hours); wait until the file is ACTIVE.
  const blob = new Blob([audioBuf], { type: mime });
  let file = await ai.files.upload({ file: blob, config: { mimeType: mime, displayName: `imts-${rec.id}` } });
  const t0 = Date.now();
  while (file.state === 'PROCESSING' && Date.now() - t0 < 240000) { await new Promise(r => setTimeout(r, 2500)); file = await ai.files.get({ name: file.name }); }
  if (file.state !== 'ACTIVE') throw new Error('Gemini could not process the audio file (state ' + file.state + ')');
  let lastErr;
  for (let attempt = 0; attempt < 3; attempt++) {
    try {
      const resp = await ai.models.generateContent({ model, contents: [{ role: 'user', parts: [{ fileData: { fileUri: file.uri, mimeType: file.mimeType } }, { text: prompt(rec) }] }],
        config: { responseMimeType: 'application/json', responseSchema: SCHEMA, temperature: 0.2 } });
      const txt = resp.text; const json = JSON.parse(txt);
      try { await ai.files.delete({ name: file.name }); } catch (e) { /* ignore */ }
      return json;
    } catch (e) { lastErr = e; const msg = String(e?.message || e); if (/429|RESOURCE_EXHAUSTED|quota|rate/i.test(msg)) await new Promise(r => setTimeout(r, 20000 * (attempt + 1))); else if (attempt === 2) throw e; else await new Promise(r => setTimeout(r, 3000)); }
  }
  throw lastErr;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST only' });
  let ctx;
  try { ctx = await requireUser(req); } catch (e) { return res.status(e.status || 500).json({ error: e.message }); }
  const { admin, user, allowed } = ctx;
  let body; try { body = await readJson(req); } catch (e) { return res.status(400).json({ error: 'Bad JSON' }); }
  const id = body.recordingId; if (!id) return res.status(400).json({ error: 'recordingId required' });
  const { data: rec, error } = await admin.from('recordings').select('*').eq('id', id).maybeSingle();
  if (error || !rec) return res.status(404).json({ error: 'Recording not found' });
  if (rec.user_id !== user.id && allowed.role !== 'admin') return res.status(403).json({ error: 'Not your recording' });
  if (rec.status === 'processing' && Date.now() - new Date(rec.processed_at || rec.created_at).getTime() < 290000) return res.status(202).json({ status: 'processing' });
  await admin.from('recordings').update({ status: 'processing', error: null, processed_at: new Date().toISOString() }).eq('id', id);
  try {
    const { data: fileData, error: dlErr } = await admin.storage.from('recordings').download(rec.path);
    if (dlErr || !fileData) throw new Error('Could not download audio: ' + (dlErr?.message || 'unknown'));
    const buf = Buffer.from(await fileData.arrayBuffer());
    if (buf.length < 2000) throw new Error('Audio file is empty or too short');
    const result = await transcribeWithGemini(buf, rec.mime || 'audio/webm', rec);
    const upd = { status: 'done', transcript: result.transcript || [], minutes: Object.assign({ language: result.language || '' }, result.minutes || {}), processed_at: new Date().toISOString(), error: null };
    await admin.from('recordings').update(upd).eq('id', id);
    const full = Object.assign({}, rec, upd);
    let emailed = false, emailError = null;
    if (process.env.RESEND_API_KEY) {
      try { await sendMinutesEmail(full, { to: rec.user_email, cc: body.cc || [] }); emailed = true; await admin.from('recordings').update({ emailed_at: new Date().toISOString() }).eq('id', id); }
      catch (e) { emailError = String(e?.message || e); }
    }
    return res.status(200).json({ status: 'done', minutes: upd.minutes, transcript: upd.transcript, emailed, emailError, html: minutesHtml(full, process.env.APP_URL) });
  } catch (e) {
    const msg = String(e?.message || e).slice(0, 900);
    await admin.from('recordings').update({ status: 'error', error: msg }).eq('id', id);
    return res.status(500).json({ error: msg, status: 'error' });
  }
}
