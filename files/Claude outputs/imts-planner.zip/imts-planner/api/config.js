// Public runtime config for the browser (only PUBLIC values — never the service role key).
export default function handler(req, res) {
  res.setHeader('Cache-Control', 'no-store');
  const url = process.env.SUPABASE_URL || '';
  const anon = process.env.SUPABASE_ANON_KEY || '';
  if (!url || !anon) {
    return res.status(503).json({ ok: false, error: 'SUPABASE_URL / SUPABASE_ANON_KEY are not set in Vercel environment variables.' });
  }
  res.status(200).json({ ok: true, supabaseUrl: url, supabaseAnonKey: anon, appName: process.env.APP_NAME || 'IMTS 2026 Floor Planner',
    aiModel: process.env.GEMINI_MODEL || 'gemini-2.5-flash', emailEnabled: !!process.env.RESEND_API_KEY });
}
