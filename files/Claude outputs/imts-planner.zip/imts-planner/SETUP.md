# IMTS 2026 Floor Planner — hosting setup (≈ 30 minutes, all free tiers)

Stack: static web app (`public/`) + two Vercel serverless functions (`api/`) + Supabase (Google login, database, audio storage) + Gemini (transcription & minutes) + Resend (email).

## 1. Supabase (database, login, storage)
1. https://supabase.com → **New project** (free tier). Name: `imts-planner`. Region: `us-east-1` (closest to Chicago). Save the database password somewhere.
2. **SQL Editor → New query** → paste the whole of `supabase/schema.sql` → **Run**. (The last line makes `erakhilmittal@gmail.com` the first admin — change it if needed.)
3. **Authentication → Providers → Google → Enable.** You need a Google OAuth client:
   - Google Cloud console → project `precinova-platform` → **APIs & Services → Credentials → Create credentials → OAuth client ID → Web application**.
   - Authorized JavaScript origins: `https://<your-project-ref>.supabase.co`
   - Authorized redirect URI: `https://<your-project-ref>.supabase.co/auth/v1/callback` (Supabase shows this exact URL on the Google provider page — copy it from there).
   - Paste the Client ID and Client secret into Supabase, Save.
   - If the OAuth consent screen is "External" and still in Testing, either publish it or add every invited Gmail address as a test user.
4. **Authentication → URL Configuration**: Site URL = `https://imts.precinova.com` (or the Vercel URL until the domain is ready). Add to **Redirect URLs**: `https://imts.precinova.com/**` and `https://imts-planner*.vercel.app/**`.
5. **Project Settings → API**: copy the **Project URL**, the **anon public** key and the **service_role** key (keep the service_role key secret — it goes only into Vercel).

## 2. Gemini API key (transcription + minutes)
- https://aistudio.google.com → **Get API key** → create key in project `precinova-platform`. Free tier is enough for the show (Gemini 2.5 Flash: 10 requests/min, 1,500/day, audio included).
- Optional: enable billing on that key to move to the paid tier (~US$0.02 per 30-minute recording) — on the paid tier Google does not use your audio/prompts to improve its models; on the free tier it may. For confidential vendor talks, use the paid tier.

## 3. Resend (email)
- https://resend.com → sign up (free: 3,000 emails/month) → **Domains → Add domain → precinova.com** → add the 3 DNS records it shows (DKIM, SPF, MX for bounces) at your DNS host → Verify.
- **API Keys → Create** (Sending access). Sender will be `IMTS Planner <imts@precinova.com>` (change with `MAIL_FROM`).
- Until the domain is verified you can only email yourself from `onboarding@resend.dev` — set `MAIL_FROM=onboarding@resend.dev` temporarily if you want to test before DNS propagates.

## 4. Vercel (hosting) — team "Precinova"
1. Put this folder in a GitHub repo, e.g. `mittalakhil87/imts-planner` (upload via GitHub web "Add file → Upload files", or `git init && git add . && git commit -m init && git push`).
2. Tell Claude the repo name — it links the repo to a new Vercel project in the Precinova team and deploys. (Or: Vercel → Add New Project → Import that repo. Framework preset: **Other**. No build command. Output directory: leave empty.)
3. Vercel → Project → **Settings → Environment Variables** (Production + Preview):

| Name | Value |
|---|---|
| `SUPABASE_URL` | Project URL from step 1.5 |
| `SUPABASE_ANON_KEY` | anon public key |
| `SUPABASE_SERVICE_ROLE_KEY` | service_role key |
| `GEMINI_API_KEY` | from step 2 |
| `GEMINI_MODEL` | `gemini-2.5-flash` (optional; `gemini-3-flash` also works if enabled on your key) |
| `RESEND_API_KEY` | from step 3 |
| `MAIL_FROM` | `IMTS Planner <imts@precinova.com>` |
| `APP_URL` | `https://imts.precinova.com` |
| `APP_NAME` | `IMTS 2026 Floor Planner` (optional) |

4. **Redeploy** after adding variables (Deployments → ⋯ → Redeploy). Functions need up to 5 minutes for long recordings; `vercel.json` sets `maxDuration: 300`, which Hobby allows with Fluid Compute (default on new projects).
5. **Settings → Domains → Add `imts.precinova.com`** → add the CNAME it shows (`cname.vercel-dns.com`) at your DNS host. Then update the Supabase Site URL / Redirect URLs (step 1.4) if you used the vercel.app URL first.

## 5. First run
- Open the site → Sign in with Google (the admin address) → **Plan → Team access** → invite colleagues' Gmail addresses. They open the same link and sign in.
- On phones: open in Chrome (Android) or Safari (iPhone) → **Add to Home Screen**. The app then launches full-screen and works offline for the map and marks; recordings upload when there is signal.
- Test a recording at your desk: open any exhibitor → Record conversation → tick consent → speak 30 seconds → stop. Within ~1 minute the minutes appear under **Meetings** and in your inbox.

## Costs (September 2026 free tiers)
Supabase free (500 MB DB, 1 GB storage ≈ 45 hours of audio at 48 kbps, pauses after 7 days of inactivity — open the dashboard once before the show). Vercel Hobby free. Resend free 3,000/month. Gemini free tier as above. Expected cost for the show: **US$0**, or a few dollars if you switch Gemini to paid.

## Recording etiquette / legal
Illinois is an all-party-consent state for private conversations. The app forces a consent tick before recording; say "I'm recording this for my notes, OK?" out loud at each booth. Vendors at trade shows almost always agree.

## Files
- `public/index.html`, `public/app.js` — the planner (Explore, Map, Walk, Plan, Halls, Meetings)
- `public/data/exhibitors.js`, `public/data/maps.js` — 1,752 exhibitors and 5 hall maps scraped from directory.imts.com on 5 Sep 2026
- `api/process.js` — download audio → Gemini → transcript + minutes → email; `api/email.js` — resend minutes; `api/config.js` — public config
- `supabase/schema.sql` — tables, row-level security, storage bucket & policies, realtime
