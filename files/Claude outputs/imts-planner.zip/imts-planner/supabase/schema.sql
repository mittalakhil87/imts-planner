-- IMTS 2026 Floor Planner — Supabase schema
-- Run this once in the Supabase SQL editor of a NEW project. Safe to re-run (idempotent).

-- ---------- tables ----------
create table if not exists public.allowed_emails (
  email      text primary key,
  role       text not null default 'member',   -- 'admin' | 'member'
  name       text,
  added_by   text,
  added_at   timestamptz not null default now()
);

create table if not exists public.marks (
  exh_id     text primary key,
  s          int  not null default 0,          -- 1..5 stars, -1 = skip, 0 = unmarked
  d          text not null default '',         -- show day '1'..'6'
  a          text not null default '',         -- assigned person (display name)
  n          text not null default '',         -- note
  v          boolean not null default false,   -- visited
  vb         text not null default '',         -- visited by
  vt         bigint not null default 0,        -- visited at (ms)
  met        text not null default '',
  fu         text not null default '',
  nx         text not null default '',
  t          bigint not null default 0,        -- client edit timestamp (ms) — newest wins
  updated_by text,
  updated_at timestamptz not null default now()
);

create table if not exists public.settings (
  id   text primary key,                       -- 'team'
  data jsonb not null default '{}'::jsonb,     -- {team:[names], mins:{...}}
  mt   bigint not null default 0
);

create table if not exists public.recordings (
  id           uuid primary key default gen_random_uuid(),
  exh_id       text,
  exh_name     text,
  booth        text,
  user_id      uuid references auth.users(id) on delete set null,
  user_email   text,
  user_name    text,
  path         text,                           -- storage object path
  mime         text,
  duration_s   int,
  size_bytes   bigint,
  consent      boolean not null default false,
  status       text not null default 'uploading',  -- uploading|uploaded|processing|done|error
  transcript   jsonb,                          -- [{t:'00:12', speaker:'Vendor', text:'...'}]
  minutes      jsonb,                          -- structured minutes
  error        text,
  created_at   timestamptz not null default now(),
  processed_at timestamptz,
  emailed_at   timestamptz
);
create index if not exists recordings_exh_idx on public.recordings(exh_id);
create index if not exists recordings_user_idx on public.recordings(user_id);

-- ---------- helpers ----------
create or replace function public.is_allowed() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.allowed_emails
                 where lower(email) = lower(coalesce(auth.jwt() ->> 'email', '')));
$$;
create or replace function public.is_admin() returns boolean
language sql stable security definer set search_path = public as $$
  select exists (select 1 from public.allowed_emails
                 where lower(email) = lower(coalesce(auth.jwt() ->> 'email', '')) and role = 'admin');
$$;

-- ---------- row level security ----------
alter table public.allowed_emails enable row level security;
alter table public.marks          enable row level security;
alter table public.settings       enable row level security;
alter table public.recordings     enable row level security;

drop policy if exists ae_select on public.allowed_emails;
create policy ae_select on public.allowed_emails for select to authenticated
  using (lower(email) = lower(coalesce(auth.jwt() ->> 'email','')) or public.is_admin());
drop policy if exists ae_admin_write on public.allowed_emails;
create policy ae_admin_write on public.allowed_emails for all to authenticated
  using (public.is_admin()) with check (public.is_admin());

drop policy if exists marks_rw on public.marks;
create policy marks_rw on public.marks for all to authenticated
  using (public.is_allowed()) with check (public.is_allowed());

drop policy if exists settings_rw on public.settings;
create policy settings_rw on public.settings for all to authenticated
  using (public.is_allowed()) with check (public.is_allowed());

drop policy if exists rec_select on public.recordings;
create policy rec_select on public.recordings for select to authenticated using (public.is_allowed());
drop policy if exists rec_insert on public.recordings;
create policy rec_insert on public.recordings for insert to authenticated
  with check (public.is_allowed() and user_id = auth.uid());
drop policy if exists rec_update on public.recordings;
create policy rec_update on public.recordings for update to authenticated
  using (public.is_allowed() and (user_id = auth.uid() or public.is_admin()));
drop policy if exists rec_delete on public.recordings;
create policy rec_delete on public.recordings for delete to authenticated
  using (public.is_allowed() and (user_id = auth.uid() or public.is_admin()));

-- ---------- storage (private bucket for audio) ----------
insert into storage.buckets (id, name, public, file_size_limit)
values ('recordings', 'recordings', false, 209715200)   -- 200 MB per file
on conflict (id) do update set public = false, file_size_limit = 209715200;

drop policy if exists rec_storage_insert on storage.objects;
create policy rec_storage_insert on storage.objects for insert to authenticated
  with check (bucket_id = 'recordings' and public.is_allowed() and (storage.foldername(name))[1] = auth.uid()::text);
drop policy if exists rec_storage_select on storage.objects;
create policy rec_storage_select on storage.objects for select to authenticated
  using (bucket_id = 'recordings' and public.is_allowed());
drop policy if exists rec_storage_delete on storage.objects;
create policy rec_storage_delete on storage.objects for delete to authenticated
  using (bucket_id = 'recordings' and (storage.foldername(name))[1] = auth.uid()::text);

-- ---------- realtime ----------
do $$ begin
  begin alter publication supabase_realtime add table public.marks;      exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.settings;   exception when duplicate_object then null; end;
  begin alter publication supabase_realtime add table public.recordings; exception when duplicate_object then null; end;
end $$;

-- ---------- first admin (EDIT THIS LINE) ----------
insert into public.allowed_emails (email, role, name) values ('erakhilmittal@gmail.com', 'admin', 'Akhil')
on conflict (email) do update set role = 'admin';
